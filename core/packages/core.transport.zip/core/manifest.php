<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1b7058d451664c4cb6e76e5014c66663',
      'native_key' => 'core',
      'filename' => 'modNamespace/8286c4629c635fba736c9c8321e17976.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '854337e13f0b9e3958af94433aca372c',
      'native_key' => 1,
      'filename' => 'modWorkspace/5dcae739d2ce62b69ee01b0b5bbe6478.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'cbe35e73b6d3c9ea844039c5658614af',
      'native_key' => 1,
      'filename' => 'modTransportProvider/358cf5588b26f35c14a84ba5150c170e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a651e47904fc138caa4221faae51ee04',
      'native_key' => 'topnav',
      'filename' => 'modMenu/40715b620661b3683aa0788583a6678e.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9f37612f150d7ada37a76d0bfceafb93',
      'native_key' => 'usernav',
      'filename' => 'modMenu/7782b85aaaf0f0b0941395dc628ca4ce.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0e66bc9b95f53aada2effe4966481339',
      'native_key' => 1,
      'filename' => 'modContentType/e02de126201ed891da04828877c0aae9.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6e3436b42def1ac436b8abf621654381',
      'native_key' => 2,
      'filename' => 'modContentType/7c4065df0c3553cfa7bffd6e6e0329f3.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fa99d7a98b33e1b45a2e633ba56fb357',
      'native_key' => 3,
      'filename' => 'modContentType/c06391c5ff13c651619303f381033f27.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '54ec1f9084d2d38a38300585906ec7b6',
      'native_key' => 4,
      'filename' => 'modContentType/d552106ef3fce2e7b1a2be6792a992b2.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '369fe961e2ccff79fd020caccedeff39',
      'native_key' => 5,
      'filename' => 'modContentType/f40975392eb938b02c23999377a58ce2.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e0ab1f364f3b5c9cae851ee2f372fce0',
      'native_key' => 6,
      'filename' => 'modContentType/e0669437a11582325c67657c317f2cac.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '97aa85fcd521517add8954f78b447e67',
      'native_key' => 7,
      'filename' => 'modContentType/9c7ed761bfd0a78c3165c5b23130ec51.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b154d4c508b43283c54d305064e2e9c8',
      'native_key' => 8,
      'filename' => 'modContentType/38d35a9612142528e91c9ff02cc93dbb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a0d38565d1a1bb18b4077ac42d35de58',
      'native_key' => NULL,
      'filename' => 'modClassMap/2c79aab2ae717b658bde30c12696d2d4.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7e0ed96987e3f557a27571c922db683b',
      'native_key' => NULL,
      'filename' => 'modClassMap/311f02426dd3db9b0fc4d1f36b877a22.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd1e792fa28b741f98366d8fbcdfe5aed',
      'native_key' => NULL,
      'filename' => 'modClassMap/132d2e9ab769e293d2148bb7b0918f57.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '436ed52fc2afd288f05aa076b8e5a808',
      'native_key' => NULL,
      'filename' => 'modClassMap/39e9b66873362b45dd04eb038ac9e521.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3aabe8a3c39c8ddaad142e82cfa05ab3',
      'native_key' => NULL,
      'filename' => 'modClassMap/c7208f13c6e39a1b6cae2ddf91e01088.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4afa26662acfc0e98ae361720fcc19d8',
      'native_key' => NULL,
      'filename' => 'modClassMap/5c666c3d7c77e1754722f1d0e83ff905.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '868cf5dec46ede413976d0de9faf3202',
      'native_key' => NULL,
      'filename' => 'modClassMap/3747e2699b319f073e3d1609d34ca35a.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4af86e953f71cfa5d440031c5d05e411',
      'native_key' => NULL,
      'filename' => 'modClassMap/f8c639ca861d0d8492fa1a7d3bd3b8dd.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6c6b2ad2914b36986381d8e7911bbae0',
      'native_key' => NULL,
      'filename' => 'modClassMap/20b6f5bbab341bbdae2efe481ef42ec5.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82cbdd13f8f96ca68e9cdfc125ca0ad6',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/96394234cd7a8f9d3b177fb38c9ef2dd.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e612f527538d71b5a11f8b9fd7e3ccf',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/b7247745f6e374b6227808a1f5a38694.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba04af6a79913a92d2d11e783841ecba',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/4e6ceff473d6375ba472eb00890e1f73.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d90599c07f61537b1b5ae4f736e5877',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/1a11f98b58f7ca3e5d2ce7a2b1b69968.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a994de02dff24f9bddaebbaa931052b',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/33b8ba231e5d706be2bdea91a1a67226.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd825074e40e4530903cd8fc80b22819a',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/3e9353070bcab82ba8668a36f2c5b3c9.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03842a9b202845c2573a7e4d832162f5',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/fb40b7520499cfea24ba776b57987f3b.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8053dd1ab407dfdc53a90ef163bcc90e',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/ab3cbf3ef12bd93b92112fe78137c4ec.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f67eae06899545a8b404690b9669afc',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/062af62de08052fb7bf99a38607e2b26.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eba791d1b3fa4ecb98e31fa34ec523e',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/19a7c39bf611fd16511a8d8ac0a03d90.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc751a63892eed68dd0ed1c920060da8',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/75ac4a527abc6db0003221df53addf13.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fc048270da40d28e0f74c2e4324be2d',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/3312f1525da406c9883a1e4b29aeb98c.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd73bc7fe3e71d0de506ff626b5cf5097',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/4f0dec8785e6a197cab99ab21616747f.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c321e666c9ae65f91d6cfdee63e45c3',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/afdaee82cf978e07c2d39524a710422d.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e155743bf8c8a448d7315a8a51eee507',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/63c3a5b130aa221fdcc04b9b131dd387.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68ba3c569db6978c639d65f49e4b347c',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5939186df304bc80664fbd6c7dbd501f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09f267d2a4b304d8a3c39d39a6bd02e6',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/18f3527dd48eed6504112e78a2837b58.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abf2b755803551ec5a213525e95c21ba',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/4d8509b42954d2e28c5b85a302edb7a7.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da9e716bdf4f92534036fd2e02e2b6fd',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/364c63292abee01a28b84395a92c4c80.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcd27f35839d5acd836b7e5dcadcfaa1',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ca10ea07ed71158e31117694d3fab939.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49df64c61a26577f6078cb650e9361c1',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/eabafbd8def50fa55acb3331c2b51259.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19560e2c5a092cd3d3be044e48a4b1cf',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/8d7100baad13bb47cdcb419b2d3521ac.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b67d0dda4d415a51ee56526f79f1ea04',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/dfb6c3eccaab9114a8aad20a221e4e17.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b4714408b73be59e58913390a1efbea',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/31f27ce4983a2e90f8c11d8e5f104c73.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b5b908c7447b0de9c446cb1f2cb95ca',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/91cc027690990ca1c4988015df29d69d.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b0edb2587187035d387c4ae2b02ce55',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/be2132036df4e0cf684095a402dea17e.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a5037f9a680b3da022f3242f5d4e2b8',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/3a3870ff23f4f44c514d012b95305620.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a02a7a3489bdbc0a7a2f646f1d667ed9',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/b4b43e82e0439faf7e39199dd77c8887.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '294087a6c704d6db0d8e25bfe857b4fd',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/1ea4fe5e7cbf89eda85e1d88fbddc62a.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de9d767609d108b87f2670886aad3a7b',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/38d70ffbe4bae26c1928032c3c981c65.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23606f0ed9da5ac2b0ef2af067f5e3ca',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/5d598301ac5c7a3c886dc69e2f03f63a.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '322bf7364f9b10b516a54808aeae660d',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/f2aa76d17f9fbc533653f0858ea9d683.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be8ab7ed0472f502a4b9d34a9717a62c',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/5366c439cc980bd3cbb3112df626ac7c.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '136b1ca037797b18678ac579adb83724',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/be1019bcc0ae3fc17b897e19eaf7cb11.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eab6996914ea73b5f2241e0a3e3ff8b7',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/f6b86c474f467ae7f0e76e5d5c386486.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ca559d245f444624e1515f33d5a0c01',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/d7e21a1e6e4ffeda3e6594ebaf184fcd.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff600a9bed6b1bb83d2192ba72019088',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/11d1673db774c0a9cf4a3bf278a452ba.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09aa8aa3e740da321ad218260c63d0e2',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/d3ba10101b1eb9c40594702e79a3b050.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fee6b186af585dcb9d57db8339ec21ed',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/dee98ecc6ffe3135f4f152debe851361.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a53af2a1bac4e73782785a694c76ed4e',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/51eb3efea892d428b5b583fb3f09d723.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0419dcca70bbae12166728cb1180e15',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/c6824f380fc2c0337b5b5f43b4d83084.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5109eaa5f2c512232ef153206f845fb',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/7412b0269fd52e2f3ce34eb906b6236b.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76bf5aa006047f9abfcc39ef40017dff',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/522564e875a1857af654a5c6e6064b1d.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '976415cda32623697c609ef7bef1f6b8',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/4a914f0088e1fbb1327530dc00831dc7.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7207b1a1ec625a19a0748c4011df6acb',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/76ca1939cfd22d7ac40acd0804af12a1.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '479afdcedadc30eefedf7a25e7f2d53d',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/3b1c1e10413e4f53d5c6cd6e606a2d86.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd29d2d6f92d2ccb39bc4399aa3bbb0c7',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/bd68e84d7e9e51aa195b3e248dd582ac.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2f7f1cd94b5a7434ca69f860c323def',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/9db6196d16dca5f7ae7dfda6ab64418f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '797fbe64b61da141df543366ac8c9eec',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/258d5f7d4dce82f91be1cf5509210883.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6b99674b3eeac8df963252d0483227b',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6a572c0f0c911bebb36ebe744fe44d74.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbec271333cdf4bf3d7962b90e03d76e',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/a6323bf0da5785ec01e873b18b549690.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da15b1936b0efb0d886a6479047e9132',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/ded91cbb711bbac1fa8ded695a1c868b.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80752903f38c048fa90fafb3195e9758',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/0cd9c3dd7204c604ec7b407e50a1099b.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f3a80a2b5205378a2bc34267688071f',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/ac3eb0955a43e66ca2394a8862956006.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2400ec3336a1724a131827114488e24f',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/fff8f50d4e3de808aa9cc0bee292ff2d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa5d47d9eb38c962770726d87c1b82c8',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/894336b1ae75fcb5a3e96c9f0ae280a5.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68d2b2739c68d3ed4987a7f08a78d73e',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/b74a60d1cd5ddf34bd7529d7d017ccf1.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34073a192791109d404341448478521f',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/f736fcea42fdce2630160be956ece386.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e702dbd17ceefaa263b132bba76381ba',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/9eaa7bc050a469e2a660aa4765578ef2.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77149a97bc43feb079887c1cfc1fd70f',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/2dfb6268cde0160d96541cd1df45704f.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfa7e0103e3cc26aa7aeafe170c74f5f',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/4b1ac6348469a0a0bd05d3170445daa6.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e1c4f803d815ce858602c5b3f3eb1a3',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/fec09bb873d89d54c46f55e4259762ae.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c41ddf7840b88ca99410fa4f63476992',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/c4a9e3f0a3434abeb389cd8232468d5d.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57f291b28f44c214ee50623b67f4033b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/47d42e7f7216ae27304965782291d183.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e11aac261324f1cf734652282cc2655a',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/9789b9b0879bac967dd4167e421d9293.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '149db1a0293aedbf6c56d89cd022e0ab',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/c6493fde196291549fce0008c541e8e9.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9e596198bd289fcb6b7b41abe1148cf',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/232d7b2711b1889b5c293fe6b7dbf8a4.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be9bebf20689a70cdf318e74339b920b',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/2eb6741b1cc1939c023f3214ad88845f.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '986eaeaeeef43fa8e2bce5d2df439c1f',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/054d722f9be131fd35792cb74ee3d412.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c709fe92d025e16662df6dcdf5c8edb',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/1c58f311fe670fbe72b478b8b7781ce1.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db7dbbb0a526840045a35e942be26e29',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/f8ab174f35dba03237749a5f62fc02b2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55c0fa0ff0a580aa97d1841f708faf9b',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/1f16be8c5f2d3f2bfaa46caef0a8c217.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fec9c9e3a5f3464837deb84641b5494f',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/a6e302bf276bef9e51ac3d2573bdec24.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38c783ab1078d1523472e85e769a0ad6',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/b834e4fabc681ddf0c891c60300ebee1.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd47cde5b75421144324fbf52cd09bec9',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/df5ea527b156e939da0c483f5f33f423.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eefe1e3c2c18fe97b91caa5819046aed',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/4901218a6ca076108e4e371282017624.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af3a010dda7ccdf17c234e8af691b6a2',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/1ed3117e164a03f57b8116d8675a2835.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de631ec8a50689fed51815900bf7804e',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/a9eaa8789aa5aa5c607ca3dad7db9982.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '327ef16748fe89a1924dc83f4dba0273',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/b161156e52a5dcb82552d0ca4457c24e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '214adf6bf94af05d4eae73290fb161b7',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/682ee536afb744145343f70dae05d89a.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e40dddd5a2d1a1e15c17e9c641b4064c',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/11e510e1bcbb50f60d4c96cc122c147d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7783c2b6baaae0aa34ed2a5d378128d1',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/7bf5bfd535a6f81162011c169df01fcf.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '235d7588f396a6ec186b564304ad34d9',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/75c4f240a2a38bcc77d6d94bc9e1f605.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c49e3316efe8ef5abf60fabe9f387d2',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/f260809d63b3e922332c51091752d26f.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cffefc39ce8be97a32a2177510ed0de',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/5ea0f88ae1eb44429ea39665ea7fe1de.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cc2a7754c7f4a001bf2238aac614b81',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/d5696f4c87f3ac6b60e7f2ce4924d437.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2f7b2095e834ebb098d31146414f68c',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/5949f0479b527c17391b22569489df76.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fbe1834d7829b4974755fa48f8ab09a',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/f8fb39e89e790aa3315f990ae6b7351b.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11a861b2907a2ae25b0a843f66a60d20',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/191ff44c0505b8f98683f92461e0dfd8.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '442196a357f2a6a465c74ae76a180a36',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/3561a2b00270c6715ca14ed5ebc6088e.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b98afb59f592a0e0a067084ada9b4c9',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/aaebd0c3e69135466199a6c4e7dffe92.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cac74c91a86a41b56698ce70cc0c4117',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/34f528896e2cc01b0880ffe556fbd2d8.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac5ef2bd1a81a18d6af5946c7e05051b',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/6935e1de14234dafe90df71e9ca84adc.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a346979eb961b94d79745ac1f14aa607',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/a4313fe545605a51ae7039c81497e1a7.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0ea320fe215692d08ba449c3fc9eb78',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/05ea6a50058edf74e9e6dca68991fbaa.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72d4fbaa6515db05be0031aa45576220',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/cfae1991cdea960af9e041e05d707f49.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb38c7ca4c95b48134fe08fab28e95d7',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/58da6c04b81ccdad0714f06883c8d98c.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f02f69bc4259981c37f724e910359d67',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/59cdab76ab605eb8df3ada32558a1c61.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '199376dd2f1f11e18bd6ac93e56b3e88',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/50990b168b93df6409c4fa123994648c.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27c7a66d604c33d5394ddb2e4aa6b5d5',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/78ed7010f4f9bc4d1ae273ce4ec6e739.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd3d850e16023bc49b7f6452e9c4dd0e',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/8635a0988711ae5555ca554092fc946a.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70a6ede1946b1c1b93fc44d6a8afcabb',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/255b3a43a5ba4490792eed82cf73230e.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '460e560cb5f25a5a2d761af53fef52e5',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/7b423f291d755abf1f49a04be9042931.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5562d5dfa3ebbd3c06f582fe8929146a',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c07df1a698fbc701c02516b96b4afd5b.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b43502512cd10dd184ecf538eeaf5851',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/e9db08f71da0cbb08ed0aa41136942d1.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b506e65fddf98de0c57aa0f9244e11fe',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/723344f560edcf5e1e1e1b27859362bd.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1a4060c4be34d2d970bd00ea0902fd0',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/909c966c9c2e3ec9ae09e219fe8dbfb9.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e31e9daa844a48696176c1bde915d038',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/04fe696d14f361d0c1ea5e2f2dab0dc1.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aefad070d30e8afbbdf116024e151ac9',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/09a718b87c09fb3281afd23c85dc4d6f.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c08c29a0daf2f15c3ec73d455a4c09e',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a750c39502acfcbce1f8e68374642896.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '158ac604fc66a139f6a11c3e0845328a',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/9f99b334ee2bf09ca13c42cf3696e3d4.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e652f1aae4c4de0e61c1973fc00695eb',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/fbaad8d6f8646bad1f95c093f445ac2d.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82ed81a6420fe70bc03b94f224be6292',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/40731f85de3b6be7817b120bc315e09c.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a4d13f13a2bc50a43170ef63b86301e',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/433da24dc4e9324043b45d67fe3e7cd7.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78bc0196a0e208d16a25a149a37404fd',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/a09726b3622298f69378e590984e4d5a.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cbda4e9ae7727a4d95057226f4d7cec',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/ebdb688aae1818e09c63cac2d227c141.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96d930004e4d0c82cd474b6d377a2678',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/7eb793f0188fd96fbfb5cae5f275701e.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '453c1f5b36332b22a406b68ad6b80231',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/9a37fe50013fe26ed8437eb07a64c8d1.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7e317b72746be09ff3d9e9f85426659',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/73670a53bf8ca21523328308ce5a558d.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e43bce13bf068a95783d1cfc42c95b59',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/cd02605687d5367d4ab860c8329ace1d.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e9f664a1d1205b7818dcc96f0476d17',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/5202ad703139069b2a7348b8b0641cc4.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31e3fca22777827d11841659a5db416a',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/963d5a92c4ce5b15614ebc84a6701baf.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af9f9c92a1eb8c2812d872c26bdbddec',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/940629d8c255ff358ad70af0d816cfee.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0859771e3ecc838781ea164c21c46861',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/68793f48e89a5b9d48a097240d83b79a.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '397e8ac4da509cc6d7e48d02c02f6ce4',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/fac24373a585b7f54e7e53e4d3fe4d00.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17403986ff22d21a4e02fcee11bbbb1e',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/6746256f97672031b54442f046b3f988.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52be40dda240d33446ecafa8ac866a6a',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/8786f7fd7319e41a0f67179d53e72638.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be791f88f6ac9c5662a9e2b584ac45b2',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/a277e4e2dbc2122e3e0f31a3365839db.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5a6b9a55a14b3aac21b4e1f8c751592',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/4080ae10f1b0992f1a435b7589eb7f65.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c7026b9db6873995fb0588332391d0b',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/c2213c549b5ad93bb10d718c0f502c84.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90e156b3a7c4b1ac3f5b01025d53c769',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/69f3862aaf91e8439c2edf4201a41255.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc2be02b03fea395f8ae56d8ada7e0e2',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/db53b90b327e1b4010e3c949252ea700.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '076027591ea6741e4a924a2b3f2f15de',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/b6c03fbed7232963340634256c3e646a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b96d479e425e335106a4b8eac077615',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/951c9d7d63e5d6048f4e8d501a7cb1a0.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46f6673cf725dc98e1c697ff11ac6a5f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/a61f6a8d57ce77309270f8dd0b16f07f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '752db19451bf6812ec5f068a600218a4',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/f41ceaff6d9b7e18764d017ab7394429.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2716a3a6e6a930e59e1709e9d49c31e',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/75624f371843c6d92ea0ddef0cc5eef1.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '673a8d7c85ccf3fafb4259bf038e1969',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/ab5991e7c089b880da4ea173af7144e0.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '077a4ce9ae01b7c006ffce9ca2f1d168',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/e4023a106cc2c013324a9716608db6c2.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f237960746d3146dc864e1df0b0846f4',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/949730d638e26f5f137c53acaeb6a2d5.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca9c4175d50a3aea50edfc56d66dfa5d',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/0b37c27e7bdd240f10921d92dca4275d.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c6f35ec3ac730350fcf7b3fccf1a59a',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2cd604b5369f574091a0d6e6979ad9a1.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7466fac12b1c472d11ff4a76075b2215',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/4c363aa650b925c3a8fc97a8362fe83d.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fdbf975507bbeba7270a1b7134a5ab6',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/ab207b0a9b50ad41311be10ed971783c.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd365f1e4ca5a8c344932586b4d1f382',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/8727ffe18bbdda197b90c7a255a420f1.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fbabfbdd2233b827054741ec1e4ba42',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/b71adf71772101ce2d95f2b232130bbe.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfe3fb0bdca06ef64f405fddd8b14173',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/e58484f8d06ed2dbb3f7a2b8028e4e63.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04ceb78a37ac041ba584cc24b60e73f9',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/463a4f505be02bf48d26bc815e1ca3e8.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed18b130d370b92c12c0c0da2b7d3fc7',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/b6e90181c7c116abbe4147f888f948ed.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5d4dbf065c280dadb53023e3cdb42b5',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/2d588c70645386385e7b2debeb68d247.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '920188dc0ea589e753ee3dbb03458a55',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/0bddebef8c65686eede5433da4811956.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2f88b2abe84e6ab29768ddcacdf7fa4',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/e337cf2d39ce0576732ba58eb05c3ceb.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '611504088cf337582d87fcbe77ce3f41',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/2ce71264069b169a5815b2a2062e579a.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd93828a6180224be7acc7cb9e0286b8f',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/8fbda27c72b3662b2255b879ba5b6baa.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cbaf7efb6ec00a62b586c016f56e53e',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/03f628a7e9f113a09288cbeeb1fec7f8.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '873df53a7cf90e297362cd5ecc3716e5',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/e1d4b57697cf08ea95f7cd1339fa3c32.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a936cc09c971eff139d003b2699b4ac0',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/dfeb4e513bce59bb370658a50a8b96fa.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54b3e7261d51e762971d788d971f5d4d',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/90d84b26cde0cc35999d4351cf6e5424.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39f5fcc3ae5a7c56ddb6d1e13283c044',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/a5a4d6cc7d2a515e67a7737aca68e565.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd07cd0cc17880f9409a03f5d21e2be76',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/f8e441c3243e1668e137db3bc931e001.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2268927d9381c45d0410d4a07d4d629',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/cfd1f4dbbe3c5a893f2870f71b7633c5.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd22129a652d022fcc763e43cc83d64e',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/0397449e5aca452015f7ce0670224f8c.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4be574922eb450f6b6ac099716d4272',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/70613b489fee98fb157988c45619f04e.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cdd710c319613d21f20ce48037f3a07',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/b0ac3870e79260f2e264eef26205b413.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '738c94ea517a6cce60228c5a08c37e22',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/33accee0133a55ca683a0ed50ad74b91.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4efb6a917b18738028d27d7d33bcb79d',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/5ec4a600423112228c88beed105dbc97.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc51e15b07a2ffb4590a75206dd0f89b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/8d6e2d83ae45dc2f77b94aed7a2a0ad2.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbe4c675a87ca291fab8de1a2b1c6f21',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/820ef06e79e43e4416fdcfa07b03e336.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fa30b830fcea62eaac8daf146e791d2',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/c26b7cf4bbf277004c133a4c8675b59a.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e05a9aec976c40026219e7841005d86',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/52b4bc500a874ad27599662dc390073c.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eac8c7ef8150fd6b1029d1a70494a542',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/8fa0b6c2f79e3ad62d9c98418f9001ee.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be99910888b1c7b2899e2552c13b4bb0',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/6ad8c0ec610e01ff9b14c7c5fcd62c85.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9143d5a928cc4fd13b5cb1f8b31d087',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/9aa78f7ec98636698505791bafc07963.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4133a5cc6c6a2971475c15b7e452a4eb',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/7c84d924cd101423476b487537167805.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce09af82aebe2fe58ab628c6b71018d9',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/e8212531922338c89682be903f05a76a.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60dd69736f30e7961cf39b68718df8bd',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/a66ab1f2d63be7246f858b75f1c5e978.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f397ad2aef4b3825864e0fe8411f9ba4',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/34272f124240a691f8219c24d89bcc80.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bec0d5b0315d2a27746a26760645c39d',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/0e16bb17ecf1f2c5efe40f662cc2e54a.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d980d20fd9049a0a081a3e5da431114',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/8edde6cc70ae6964156766b5a2655c06.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aed9594fb76f853de310590cd32b2494',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/30a13d2d9e3767616a7f0cb18e9ef5a2.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfb028a7de1cdfca728dae534be551b6',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/837a9c9b94d13828ae0d078719b57d28.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98759126f9f2e6542b7549396f932f8f',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/f218591fc4cfc88dfd8772dc980f4293.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbb39d365077e97d2662b6830e6c4845',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/1bdaa3d2faf4f2dd7088dd554d4eb80e.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53ffc278cc188abe4887104f35395c90',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/779dde230f392e90c82f086c0eec118a.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91de15c8a8ca3400a83b995704e5594f',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/37f5157577a75c0b04dd38d7839b890c.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbb22ea2774bd69be2b31925d2cac4b6',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/3d4608a80068c90d7a264e3c5da6a67c.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10d960fd828b66b447ec164b963d3c79',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/35b229b3765d4d65262cadf16bbbd856.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a5078548f5d051a75c87352e05fb041',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/4bdbc41b4633534b169c199f4f32bd38.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf331a0126c4027a9df38ca227ace3f9',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/8e60e1dd842a118c4a7766efb9402e47.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fd42acbfe8518f5cdfd3a6ed2c24366',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/d1fb39d324ce9a407a73a4ffb484e3bd.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fd29c7243dac75c7cc35cd686780c81',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/b59d4e6fbcc7e6dad3069f713bf3e2fc.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f462d40cc94d8ede562aedb2dc9afb84',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/05bab34e57c2aaeab9c47ba94736c87a.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b80589a4b7baa66e6b8af88af8fed3d',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/c20e86b3d5a9e72769a1dc0de2d71453.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '691f9766679a81849126045f23b3bd6f',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/3992096d56b20718a0f498b2717e6301.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e81a01ec7e11448be13187f32f2345e5',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/56d78b452fed8a94b682bcccc3076d2e.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '399aed59901e936034881ba2cec3c37a',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/593a8247275b2bda92f0d86733df3c54.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70997e9c0d6c2870dfb93c3a16a80cf6',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/9a83674f7b31946e03f9df538a540347.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12403d43ebb171dd2fc71c3347d98757',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/7d11ade87dad9330beb7914f1b83b149.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74830aa60f85adf8085412feae6b45ee',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/39007a3d48eaa3b577be2d1646bffd68.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '678b098d50c58c65141d9f4d8dd56a8b',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/3a3f09fab41ea1ca7e3d8ed0608fb470.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '783afdf2b20795b25d95ba570b8353cc',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/a8993f235dd6106cf6d815b38de6befb.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae8385d15489655102dfd2a89ef9ac6',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/a28d83e492982b4526065d15f17eed18.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228df0205456f7dd2e31ca5f5c05ce80',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/13310250812f4da064bafc90c323a691.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f445d752a2dc0bbde000f13dbeb9eb9',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/63fac799e35beb09ee701484c134dc0b.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e9c85485ba8ca28fad2bf3644990741',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/cb330e2f52541041b023c1e94bad1c6f.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '240cb76e47fcccdc7f14a5c521cd017a',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/9d8bea757c85088f9144f99f183dc26f.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc82767acbbe79afca53aaf000b9ac95',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/c0842e642f8a2f0b9e0ccb5dcb98c753.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a83029bb7abfedbaf7ac0b641e611e6',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/0f74efe15be236f3688ac628aad6a2c5.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01a6ef4521138fc48922ed6460751aab',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/c4a28f57c5e4c87f6cc03068d096baf0.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '508d2a3051a2d1b08e840fa40c3b0db7',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/bdd92518ab19e01a6ae76f709429b8f7.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b8ce7e1e602a8294c9976b2777761e6',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/bf29ec7f7151573c63b712ff0c1c297b.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb9f2f8ffc2e2a3a9fdb96e9adb27b77',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/c461afae9f9225c9fcea5c77233aaa5a.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2975691e742162b92b6beaf90ea5a411',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/5db5a52ea6553f8d7765306967733ec3.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '531ec6673af0e77626948ef2f22134a9',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/b0d25c1ad08273a09c4c6dece0a99d4e.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba7fe3f475b92895dd8f170ee2bf52a3',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/7ca6162c38cda4de70bfbad3508823a4.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eabeaa7cddc7a3620508a386dc0b289b',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/1fc9ac7d32a437f3e500d0909d9afa3b.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ae5c7c3a3221cc771f412dd458349dc',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/22d11a54686a97b49210cac707a94463.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9096933e946a26b0f0608070f25d876',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/1a694b7c60a99a85ae67cc6723be3884.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c65854ee9de77da55e3403007c2bc4d',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/c1904cba156d16d666ef5939f90d7daa.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4190eb7e2ad0d18253204dbfebb79031',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/97586b1262d4e8f4223ad1d2114189c3.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '937e9a5f91398f1fae61e9a965b942cb',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/f70ee13edfc78aa8b78b12103811faa9.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5afe6be0564edb1288842fb7fa67c8c6',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/df50d9925fb2ba640b7f87ffbb75454d.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cc650af4bb068f5faf30d6e616d5fe3',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/b57e5f1fb8e1815f2c8730cde9b63f76.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '100a893ca1d49da33b541c7160962ec4',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/2f313f21a00ae7be96d38bb5ec0744b9.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c080177546799a635165297a32a5dd5',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/7a69219a7329a765bd5bb96bb3f10844.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7810801562fb6001b137323c47928fe',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/5314a1f84fdd44603191761e7848396e.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c61bc8344b48aca5c8eaff9aac4889b9',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/f3d6374b77120222163815301c0967fa.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68f409c0769cc2bddfcba23f69304347',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/ceb32c22fc0d009ec42516b93b6e9bd5.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c226ad7064ad200ce912aa3c37071c5c',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/daddf66a22836d224a892fb95fda4ca6.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0e0e1c495c410dbe30fba42ab44f502',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/8965e079197fbc33fed2fa9bdaf0f0fe.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a85cddf43edb2007b606cb10536a9740',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/97664491e77f4e87a3e246dd25af269c.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38aed914118471ffc39ba0709ac6637e',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/0cee49698c7778b59a6c3c1bd123fe02.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c7f327b0f0e84725dee27cb3bfd6a91',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/fbf5f317e087edf2830ca325752fd737.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aa52d4d7520eee7fa7a8b03ff48a538',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/051902daf9c60d9004415ae022ebfa3b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cabeda1abd3d712d0fc2e827b974b58',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/b94882704a02e9b300dc882b70bba0cb.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c0da8b31699a3a78ed5dfede972cf92',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/036691ccbed292761265e1441c404de7.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d9bec7cbaf3c138941381d9c488fbfe',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/4ec59cd0f90e2c43452f1027743448fd.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2fbb1bae358d1232f2f9fe1dd68ef73',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/584db483bb1021445b96053b4fd33bb0.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7adfbd81a982b512c36ea699a4517cff',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/d44fd5beb610a120fb75d28be1a5b395.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '034d3ab5ef19a21cb776e82f63b9dcd7',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/6264d1a5e0bde5d96aba2393f0cb2e98.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ee654345c55e3eb4e32ccecb826bbbc',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/3255547cac91c7c1711fabbaed6170a7.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '624343988bf8610816355c867420ea05',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/18583cccb0b185f5d8243924b15f7544.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dd156ac363e2ee736e91da132739dd5',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/25ce1395acf4a6cca8d45d96b913475b.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7f1078da6e28609a32b76e5e4b6a746',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/5d5421429674f449fbb596b795cbc60f.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed0d4df08a64196197c42f4045b481fa',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/65c993caa5f3466827a57cc9a81bd94d.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4a063fdff9033cd93e7afe3b9a5c6cc',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/01e79225b0b917bd9bd162fb41cb6189.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227aef5359bc89e57e5674489104bef3',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/abf8c3e4da1c57bd16e215598d8edf33.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd36eb8d95f6b356fd148ef7a9d980789',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/271912beea3ff70531d25b794eee43d1.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '477a7648ea893169694f553d2ba4467f',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/a218a2d321afebae81d2c3de2e3c53f8.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f408d2d13ba4f732616a4aa310ed65c',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/b97dd55481da9dc08ca63478a210b92c.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4fd576995573922ecbc2b8d216f7ae8',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/95da9f1749ee847c5f2a175a941116b5.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82ab3a58b90cce7c50001697fb0b2ae8',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ab28e3561caff7ee7728583fea7fd746.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61d612706822484f97735d4735cc9325',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/5c58ae0cdbec6fd15d5cd4a5c7f38e57.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede07cc7b2eb636639b935fc72e75e17',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/9d03c7d55d7ec7d8d0b03b28a5b7ae31.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29a1be81aa51d64e296811ca991afdb5',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/e0a1d256427e49e793e251f43a1e3425.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52686545c428e629064df3ee77b4f6c',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/f0dd9e6bc9601af6c85f02c1cd8ff87e.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bc07baf6ce30e18e93f4ca25c2f907d',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/4005b6002da9a3e203ab414869c01bc7.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '393805f540db7006f8b1513c43f83539',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/f3066aca550a0eb6307a1ed98e5784b2.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7dde1e3db795a4f862bbd93e2d777ae',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/71c07e735084e81ac0c70b246bffa859.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36f445a51c0fe574e380431e74c3fce1',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/d6e36a4683d1fed62c0a9aa27166b12b.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '650f2c023cdc0e60b73613167a166fc6',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/8ce26a83a5a20f87c628f59d8a8ae3ad.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '269daa99d9b4ddfe5e4bc14b1a5d4ffb',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/01286381e4f6fab8383d6807f6103738.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbd269306e6dc808a4495ec947e51b8b',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/3ddceda95cf465e704f9e93005d1d190.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13b658eca095f952eb40e4bdd4eb4fce',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/aebaacea0f795c1e566b16b00d075cdb.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d6a59a53848b5bfbafe6808851c108e',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/922019bddb1deb69b81e798546be980e.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9128daf4e98987cc1fc6eeceef56fa0',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/579e74370c06139970ca36162056f410.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e04fcee87dc128f8d29874e0267ce264',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/617d984cf69cf30cb9d4789c054c9b79.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e30cc8bd5ce35ba88aa71b78776a6058',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/616f7fd20bd951a21f05291e16c01ab6.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a7c370229e011591fa208cf4867703e',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/c2a41aff08268f9d8864469e4bbced02.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79e94afa554cab6688a2357d47f73669',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/978137108c243dc0aa32ef9c90c63baf.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dd4f77ce241cf62cd860a24c350e97a',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/8841167b3dd1c435008f52137374689d.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89cb55861b61ec57888885422a67f0c7',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/141800d46c629b68092319d2b53d9297.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0360d6dd10e0121ea0859d40d0eb098e',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/1caa73e0031de4e6b12d5cddbac41988.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84c0badec86e19d2113a92a7ac2141bf',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/f2c776cf5f06098f0b21773f56d0b4d8.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e983c8f3449e2e0d40606065915674c3',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/0870392a8c526617b5961e6f0787b0a9.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3cf396d2aecdfc90c170d06ed23ad18',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/dd067b451a51faeef72703d0088d3445.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db790a01b9156afa607dc46ee0b7a61e',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/6bd05ba48106752ea84ade3b35fa4f91.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45a43846cdf0126943673eb4484254eb',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/19bbe03468b9323cb5735082a6ad2288.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cc3f69ba7980199c88ce3183ea43079',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/b10a954395ef4dfe69f072b4d9e78386.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fd21c94105edb393cf4f7288217ed5f',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/02f6269a0ac65489b4f37ba6dd29881a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ce67a01430660f86f9be99fe8ae9a0a',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/7fd2915b4bb498e83a6295b57e6d34b3.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eeafb889916ff8e783e4bfe60e42e71',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/b483a176902e1744258e0edba887f6f1.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c684728cee21fa65b96eadbbad911c4',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6510f6d61dec68872d8c91832eb1e189.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f73ea0d84cc8aea321b75bbf868a10f',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/669abf3d3071558258745c3f157b7e8a.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '934bdb7d4f470ce8ada0036d5d2d8436',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/3c139cbbd43974e0667fc1a2ceea1a4e.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ead3694283106b708c5a96fceb085c6a',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/a72a0534098e467d2c7cf141900d54ac.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56e208bc7791b663834fbb7e1a28ee6b',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/ff657e2de90c873d6b0365f03b41e179.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3dd9c435a7e5296fbc9aa653f24890c',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/32db2a0f639f4f312cf9a9ba095aa752.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ef364f68e7e2af6de2ff6dcdfb93d77',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/6042d0bd1b325cb1d120a4d9880d55e9.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '172c50524d92439f8ec54c973eaf5484',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/89beae3dcb276d4cce2fb9993ca53fdc.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab82e7583cc1920f1606b4a8a8238bdb',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/314dd18bf697eb2161c0445e57424763.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b60165772e121cad3b760161cc9c422b',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/ffe93510eef1578eaddc81e9064343d9.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eabdf176d37344e298b3dcfede52550d',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/85675efc589114a20be327619d70a6bf.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '219dd4219fe4b3eba725d008e3020042',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/ac0f5c6dbcf66dccdcb4d333c40c8711.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd738597e36871f27604d4686edbf188',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/dac9e2683028f4d61253a134d1df3c90.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdc854c0dafc3733ebf9b59da54272d7',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/5ed5801e6e474a8aeec32b544714edb9.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a4f4d3ae29af9a6b2257fc8f7f585e4',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/5b5b5e92e124eb362791cb9403393b57.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70e2fbbe1a6b7633c6aa0f76332b1261',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/de8ee6e3e40baacacc9e43051b2e0f03.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '836cc12aaf4ec66b72647135419422c9',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/5a403b7d9ec3b9e66b7682dda7badd06.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd70e147ed559c185d9e2324bc1ea49c0',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/468ca3dc0652c9cd3ef80cf9dc4aac6a.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68dba5fbb946a0ed05bf76a09eb5b191',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/8d55ebef45769c3ebce722ffd0d5044c.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d3d7272f5f840e34cf7ac293fadc33b',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/c262412046b9e2d5e0dfd5431a0fbeb5.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1366d0d145e6964a56107a5405395b5a',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/ab72342f9dc889f899964ba419a5a67f.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd110af6cb83150b4c6829947739c8ba6',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/43b3552e6ccad9a5b629876ab4280778.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433e3cfb8ff2166f3d45176b942064b3',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/d108a7bf610de9558f6da2e16d3898e5.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18d6513ad6bb83c232454227f0094f3a',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/c41d40fc6b87e29bdb5247e040cbd2c7.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aca8b0332d12db1c969927d8877fa4c',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/f7dae04e4ef61c2be4088b7247259801.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d2dce12312a8553f75a545bbe8c4d21',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/f31e33dc765531c392575fbe5c917432.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dc9b4cad438719e92b4cd47e335ec73',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/c765f69bbcd72569d0a16e066788f6cd.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99c258bdf55b0582f4a3df934703eb55',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/44d97f017f193ab899e7ca5ebc3b292e.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41912de3ed21821da4b7d1ebe3161605',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/d8408450820a34c34e84d4d651908ecc.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7d401781fb1f4cb603d0c07eb3d9564',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/91519e984c14dfa1012a871ab019986d.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d5ddad5da8911b59ff4748018a758c6',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/747d13f0ee44c6f4d13e32889ec14349.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75a4c7df9c19694cb5616d6a27183be4',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/69f40c78e839e3fba894d9b2d71e3fb9.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe253026e45561e44f52fd7bbddf88c3',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/e090136549bb4d2d4f64456e7c6c7dcc.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ee1537c280f03d0bf7d8f7ad699e961',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/5882fc286aea113c7ceb3f526d72c139.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9efd4a03b99ccac1423828eadd499049',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/7c3757f240e63e335389c2137575fd47.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae87b6650daa716c6b8d91623ee4b9b5',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/b25205fa42c0687a1b6a5a1f4b228a1c.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9ebaaf9afc69b2d8896179d82c71172',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/3ace4c6abf0df019736f6d68ec4b6844.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aa01c3e136f3e9bdceee365769e9858',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/16f8850c06bcd748a03726eaf25b784c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad0c7bd7956e15fdcc85f399f337fa5a',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/be30cd8b81d9f7bf9356d8b5b31affcc.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bed68f21466a6a40f9c0db96d6cdfab',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/1a913c03b719c4cf72091aa3817faa26.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14631fbfd0461862ca4e0ee2cc445256',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/0c0da742f36ff7c3faafbe2b9bdcdc35.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7af242cd62da295dbc6d470d1f001fb',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/5ca8ba89b0cd82d0e31260e0f6f3ab95.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b3080d57c0224dd08f71ded4f8b68e2',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/7363f1ce00ed94cd1a0afb0f0bec47a5.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0de6b5e5ccb306f8adb06f9db7f65b24',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/eb3a5032309793dfa270a7cf2128fa01.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10e3c2ea5e9d69f4457f81cbe1644695',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/c13641226370a56067bf99ec9c220211.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc1452d514481f5016e03582f3ab785c',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/2f5d073f18689388946de9598c9a0087.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9524b853fc43e8003ad163a4b2638190',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/519d99b1fb329586624ad3caff0c8c20.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6b2bb34803f9154e5abf24a44b523fe',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/d6765a4566b66fd854f1cff4332bfa99.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f26a2c8cdb0823d1373425abb5f477',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/d0e47edfec3eeb93b957b603aee85076.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b10d48c3f8f33a2d722f7645cd22f05',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/a2601111f13d0a94f34b72cd3d42f0a4.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e289a442af497889e8f3c6795437e14e',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/2575c859603fe9a2b4c3d2a1ca05bc79.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03589dcee8a3ebba1c7be92531d0726a',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/5b0909cd84d92b6dc796915cb171dab7.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '090cf025359f96bc31b9c7b2188ad17d',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/66e347673eebb557695854d9a44a7770.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b700337699448654c505e6b2ed7048c',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/c397260b03b592e86292294b7face5b9.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '502950c49885a69da285983824cb980e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/ed15bddf746141bf0732d90a8cc22197.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a52705e3634198e501405ba90755a28',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/97566a83f3d215ac6277465e1a420b88.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0d081659798637e5d604feac156fa9d',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/77f770a3e2e6ced69aaee48caa2f16e8.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0fa3e7fb5b45a5d2113016445f940b4',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/3ca04cfc2c483d81ee98e25772ec62b5.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e54535592690023bdd91a320bab295b9',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/308ea7366a7b497947499c20f1e363e5.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '590eee7925ef3cbe19920fa717752774',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/a187ac025b462b291cfdc2d674dfe759.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '304aefde9ac88a73228194788907da87',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/4abc05a3db7d596064418492b87412c9.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '971ff951bea1ae69d41b58c19cdadc73',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/19c2e30f2fd58074a410bd155a4f01ac.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bee21ef240251476d0edf636e435c49',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/0c3e977125fdd9c8aafd7d0012de9733.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56f1680f550cb6d60c708172612b5dc6',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/2e9349978100c305370fbd53e753f9ee.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bbc9d3c69e7128f71b4371ad26efecb',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/42cf9f7371fb14d48d19bc72cd536dbd.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '102eaca6b310f8ca6e065d64702376ca',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/8efeb3c5e1f7acfb95ef899925e5f411.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b34880f26cb9e430e3007f77cdeb92eb',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/a40a55df7fa2538e6fc713e7449544ca.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fbbf7f4799a87a78f35293da070913e',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/b4f42366fe743b085c2f2dbf7986d30c.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3951fbd41eed0b2f05edd45b06a11ef',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/6846d41247720ce2382e77f0f99a0ef9.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4fdaa9e26d1724a93e458485fd2d23b',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/a625fbfd846a708999c277abb8d55aa1.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b51a8e91b1a1c9d6d90d02fc1d3a10c',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/a2a601570bf24ce0185c1470313ac367.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a042a13af2215bec1fa6e0605654efcf',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/a6b7a64f19509f51503da595aeaeee98.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04674e56563c87fefd52962fa3181e9',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/0ee9bb60e9a4220dc4f188d1f1fc1ce6.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44b18f4cd186a4749a8cf6d111900df0',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/369e63fa491687b49337f81483d1228e.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '480a4e195ab47590c3503cce4bd79092',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/e824a71481a8a14b204422c52cf4ba5d.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14905f5be23b1abde76dae69260b1dd0',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/a44c03eb5df5ef9225139553e78b415c.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43dddd2b5ee61dde2cccfb501f6bc8f5',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/aed62c1ebebcf80c6e5fe23916c7da84.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15823314d279246cb47fd45d7b956951',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/5ae59cf31fab7b8e6097e4b9d8ab2996.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15d4cf8aeb683a61f9b3073055d0ef6f',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/690ddd2c1e922b4d043198b1bf3a9aee.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b275d63f38e9f00e1c18a1500a8ff1b',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/031c9e62f859e6936031067599fc089b.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6db1aa157894d93aa8aa83b372bb1560',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/93642b9b216d187b561a967ac7279d71.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f64a211ed1b8f74165bc530673d44279',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/d15162634203a00d198d573acfd9c23f.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41fe107646579170d87a59751d6b8413',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/723b6dd1d0b6cdd82e1c7a2646ca6668.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd37cefa1561f17f8d0a205e3790bf7f6',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/c77385e3f81a184ee3c70b1d662b63d0.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dd18553a680174d2f6beef47f78c1a1',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/f8b1fffaa20b493bcd28d0888968056a.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cdcf31a4ad2e517230871ff073276f1',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/8d2882f473877306c2b9ac96d4599d82.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31192ecfd8448bf1b3f06e494741726a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ab08afba4bb38b9fd8eef6c3f1a1bad2.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '495a3fa63a44d8a90fe1f04d89ba345c',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/205976d1c09945f074653aeec51bf841.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a76cdcfc06f4da9ba9776f29b682eea',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/9c01a7842c97b376a0dac3b832a37b27.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ef1b32a76e0fa5f07ef06523352658b',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a1641234178955389312c55fd41bf05d.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c60fd64d58f0757e3d58ce63a8bfd38e',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ab60529ab068bcc5eaa75574ee85d18d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b00473a9109f26abfcae55ebed44a172',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/df602f94334fb078265154a6d83af7e9.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f26c1f6cd367c814c313a251795f2f77',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/8e60faf4f0d682f44edd6fd22bcf6dfb.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e3ae3ea2c794bc1267db27dd9395066',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/3c3336f172772b7f9d0e9b9f0e063244.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99e95fe2afc1c8da93295cdce467e1b4',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/97ba5aaf7702b31066d4544dd2260431.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01c21e6619c922f982046d096d7ec2ae',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/c7247e7ff7898fedd08f73d28af0ff38.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0154a332b601c08d5b7603b4a71dce77',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/cf9ac2199f0460324fe78ac12f2d86e0.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eece0a1161f12d676f414f9e18222257',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/a50a38eb092a89ee35628192b1512c85.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db348eaf7608c5f7f3be997cf0551dad',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/bc0dd4a88e637c10f8e700370dfb850a.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf255bf58937c13f1b52649214d02b7b',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/35fb3a8865868966c564252e4fb6a6f0.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28a454a1b07156ff963824d79abe15d8',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/0d1338290f8c5efd4dd4a5352fc6c4f7.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89b5c961d4782bec5f9fafad03bc4143',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/611f2ab8478a87fc864c96ae7cd0a947.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5071cce8fd9a458b6e6943b71e430974',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/f76cdf22b848d4b7ddeee97c7889ea6b.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2db31bc9435f5e588a66de93f06f4a53',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a6519ecd6ef21461b5afaa3b88b0212c.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15a7d7872d60229ef4cfa38c77abbd07',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/731d77f74ef8ef3cc49d78eb71202371.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51d35d90bf1f3cbfc19379f3cab4da4c',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f6cfbcd202e17750a81b99b261b6e3b4.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb5c065cd856cba4f0c65520003791d3',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/e17dce507bcc13ae7b746ea9d7be31f4.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a5f197e2f3be6aadaea19d93226df6e',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/8e4c5af7236b45f9762248670a2e83c0.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c634b7c6fa12455f611fdc6f33a4f2ad',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/38f1505b5dcf26a9417cbba54895bd54.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e998ce224ca847b687732f931008714',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/6029df97258d4c9b222570ff1922bdda.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a2ae23441275c26008b5379c36cc01a',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/6fd19a7c853f89e7a4347a97c7900a78.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ae72a328b7b0eff8e207df119f2dfc0',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/af87836d45d6a3a4395746dd526dda4d.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bba25b2ac6c9df0384ad9a74945def24',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/de6971f2e903702e66919917bfd75e39.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8ec7066336b5f7249f0afba72ea9180',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/bdbe1c447f87375c2d1b75d38eb72192.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '766b4e1bf11d8d17c3f6a8e36261f22d',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/5789338d83353f1fda328b18825a6d5b.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc785e080cd1c1d02a96dec327d2d8a5',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/71d4e79cc7ccd146d0fdffa2c27f821f.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcab3952e73c99c19089ecdd92c77146',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/c819c5212e0479830845cc7daba6aba9.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccc8de02e19549738e17beef8bb5f88d',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/a01e49ac398eac39bdcc6377f9c92729.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c80e84ce0735fa91864922293bd6bb6',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/99cb93aa3b0c6b90bd1f81b1069f98e5.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02aacf29dcfa97a15279b7345c658e46',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/69b65ddf46424d93c54635f01033d6f2.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7a66210f50eccd0637d15b987ff8e18',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/398b8a4297d7e6ad45572b15c864aca7.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4f1bee9949350a33d05c6ae53e78d48',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/c65c432516f542dd7d901c50f3f97853.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '416f3a6a56b8ff5e1f57db5480e0cf97',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/b0a762516060ad9b6a5daef7a31d2a78.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '454984ad691654c971c46e14178b12d6',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/a1d73ad6716fd6526e68a7d26f605ab1.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0d5741d9ef5d2a087c497fe64b7da06',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/cbfbcdff1e1089efcbb2400dc4718992.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fec87c09b9c0867141d1b1966c4afae5',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/6150c63fe44af3ee6156d1faf6de0abf.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed24df61c2b4424c8cb301f133e99c90',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/d41cbaa7226f069a5174aa2cf51764d7.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6f2eb1f844b403ed6d3707a78c5c162',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/f817cfa1289a576cadf93f1e5ad473fa.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bddddce2b2aabf557211279b42532cf9',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/eac82781d9e5063ed1ab47e6ec3bc271.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a296e5b36a84559842948f2aba4da9f6',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/1051521269a3250c231803c7dea6f594.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5510001480f15d75170ce15554262d77',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/9bb56e07313c755e9d3d8a12476151d3.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '171856687f717138b9643731d4fc9f2b',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/8ebb91bf2d24d7f3ef890751322a833c.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9000f91fba897c3f24d2ae2df364b1f',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/7da83059ae02d170c3a01c900969f098.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e2acce8e372694a768f62cb25da24d2',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/0b85e02070a0db249c55033123de86ec.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c05979cbc7d23d01ef7f1deaf259c9d4',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/53f33a48c3b6dbebcec0c4ff6649a38a.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'e485d90360924ca1bbdc39f05034f759',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/414e4c92d23ddb34043ff74299e12e13.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '629a4530fc374cdfa7044c5657e82761',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/4698d0c8e048f4d8474f5bffaa8c6a2a.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '327f453df99da0f46ba6524919ef1db9',
      'native_key' => 1,
      'filename' => 'modUserGroup/cf3782658bd05679f9b08195fbeef47c.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '0972dddb16078350e04c8ce382d8a257',
      'native_key' => 1,
      'filename' => 'modDashboard/393f3fe4ba124459b5edd6f020f4d1c1.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '99d7f089386ef4dfd11f553c0f15d59d',
      'native_key' => 1,
      'filename' => 'modMediaSource/5a9f9c1a56ba844ac57e0cbafc3b95cc.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7f63935beb7b59bc61e059b6f399a6bd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/085bdc3a5eddb5c18b9caf22454480b5.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c083e68191be735064c856e2d5a8e8c1',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4095236af2bec02c1a27c69cb0b09c57.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ddaf31d6067b58d7302c466b73e480bc',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6129a62856ffaf55f4d34d09187bfaa1.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd90fec4483db578b0eaf254f1417f6ab',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/90aaa621e4d34305b540662cc017ad0d.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '31ee68f282dcf547e029401fd853e61e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/40a117a9cc8b8195c1953c76d85a1e1a.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'bb3eae380d61dc2d85b765c27df16b02',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/f89ff76f26a41e3e758bf4457382893f.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '8f6d250a17861b998f229b1bd7559031',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/1af772066df1281aafe0b138f8fdf408.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c8973077b5f43182c984c5659df69ffb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6370aaa12420ab5ae261d05ea0e7a558.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '61e1f4bc87f8053de1c25c2ff808c88f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b7b3c82fd091bfedf4d338ae0446c73f.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'edf81b4bb745e0e9dda60b5d8c684bb5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2f4b71d198c23e2711aa8f826c58b403.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '17d0b955d115257ce4599bc9b739ab0e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e77a117f791d71b4cbd5cec88ae98fde.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'dae60cf122b83bae4bf3ca2619ead4d9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7735304ca23ad86781b8398b2ffb7f6e.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '742d46024c8127c900b54c14e85857c0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4220262f04f49523daf6e6ce2e8ba76c.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'dc4ec75960bb963e5e5bfabf2782d8df',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/612888e0022f5f8c14d75761b62ea87f.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c0fbd826c994c4ce5508932b5cdd54e3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e97ceb551470da7b4d2dc7b7f517be2d.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a94099283aae1299ffd0e356d025a794',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2433034d6b53b1def11084198b632e9b.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7c6aa107c36a58f71e63d5ab60a99770',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d21f5073cabba123d5605d5697e003f7.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd3664bff19430e081c705d89aed3aaa3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/da5bc0e31d4b88131e2353b32dfd633f.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ed37f709332f0cc046655aef51da8370',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0d3da4734aa8eb8d893e3e58b00e1a01.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '69007cc05e5c02514c2688864b8c9206',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8eaa929ad2ac71b89706addc32436241.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'eb985d1e3ac6ce6291e999a4b92f82f6',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/00cf50ac6346a5d678811ede74e36040.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7fcbdee12d38af60eadefdf066db89e4',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/08039bbeb7676a19bffa79f70142dae0.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e6b0091af3244844b265fbf948fe0572',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/6c78553aba15afcfdc6edf201be67cfe.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e41c448ac8eb927dab16a377cb0958cb',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/9199b08779a259e5db9f269a68d6fa5e.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c8302a8438ca60e52a5e5fc338c5c4b9',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/f519e72a5a4190485165dd092ab8b466.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '48fa66e5c66317b41c8b658a0139e1fa',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/6ebadeeadd0a6771f926246554f0680a.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3c03fd9f5198d6de7ba38edd4603b138',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/103f5394c3748292b5d02e410b2a8668.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3369cda8195c7a460ddb57b9e1371137',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/6cee18b5b4f7a8abc09b88ee315f0afd.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2ad7a85ddfd4806e3ca5e183bffbb91b',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/030df01bde11d4675ecc524ab9dac90b.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'abe564fb9bb805b84fb41d96e61ddbb0',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/0924abccf865de0e9c8d19a140afda49.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ef6fcbc2305634b4d076c3d960ea4377',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/b4a729e81e5342e152ca5c3892cbf45b.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8700c6b27f7c6ba8a67a4b0fdf698b45',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/ce7ea1511e244ff15427f4b92b0e0d3e.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'e83b376e0826d03bc268580a8014b74e',
      'native_key' => 'web',
      'filename' => 'modContext/457ca7a0b0eaefc2ca1c7c6e01be469a.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'c0ffa1e05bf736bea7945691f4f01531',
      'native_key' => 'mgr',
      'filename' => 'modContext/55899c07a0be09d324666a6a7964aa95.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '624137903fa2c9a88d45f0e58ad5e74d',
      'native_key' => '624137903fa2c9a88d45f0e58ad5e74d',
      'filename' => 'xPDOFileVehicle/ffa5502778b3fb87d28d02f45d927841.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '031b3f92e7949f172d820b78acb7ae52',
      'native_key' => '031b3f92e7949f172d820b78acb7ae52',
      'filename' => 'xPDOFileVehicle/1149241767cb39815df8fc2114a9936f.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'debc6d961c3845659643718b34ab12d9',
      'native_key' => 'debc6d961c3845659643718b34ab12d9',
      'filename' => 'xPDOFileVehicle/abadc8773bbd03d54796490a67534a63.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'aeca264afc4607211a5b32e97632051b',
      'native_key' => 'aeca264afc4607211a5b32e97632051b',
      'filename' => 'xPDOFileVehicle/229a573898f3733982f59f406bed73e1.vehicle',
    ),
  ),
);