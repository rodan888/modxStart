<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '77f63d74b188518eca0e39d90dbdad54',
      'native_key' => 'core',
      'filename' => 'modNamespace/c911f568a66bf5318aa1c0a8b03c8cdb.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'ec80197f3ebf9a21d2b39139a6b84a2c',
      'native_key' => 1,
      'filename' => 'modWorkspace/43993f979bc6c5224a7e354196db775e.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '4fe820cb143cb3f4a9ea714b91956b26',
      'native_key' => 1,
      'filename' => 'modTransportProvider/071d410438f561202fd804ddb7116438.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '50d36ae095a19575586d45dc6fa052ed',
      'native_key' => 'topnav',
      'filename' => 'modMenu/031d242f47822b9a2078c3cf2593c6d9.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8a942e8793d718f707364e2ae2f7297d',
      'native_key' => 'usernav',
      'filename' => 'modMenu/c27e3f0f5944645817fe97341ed7a635.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7fda29d173aed4c45d1ec8f11ede9ad7',
      'native_key' => 1,
      'filename' => 'modContentType/2ebddf9fafe454dfac520fb7f0449694.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c1bbc67d067e45eca1cbf7179f490407',
      'native_key' => 2,
      'filename' => 'modContentType/bfdc936092b1d62e43422af0674494f5.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5d32281aabb1daf240defc1d649e8002',
      'native_key' => 3,
      'filename' => 'modContentType/bcf1d88beabd8bd51861d33e50ab6224.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '18fe7a6fb2e1e29f842a656a05aa140e',
      'native_key' => 4,
      'filename' => 'modContentType/3369ed66ab17ce1af462ae22b6896fa8.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '32aa831872f8bbf80750260a5b92be9c',
      'native_key' => 5,
      'filename' => 'modContentType/70ed5f5eef1b6bc6d6d28980f3e97513.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '764597eab3aaa3505ebbc3fe5287edad',
      'native_key' => 6,
      'filename' => 'modContentType/385680c62dabd51be84e0c2a638eacda.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7f886e5e4f7d6ba282b849c763b843fe',
      'native_key' => 7,
      'filename' => 'modContentType/7f7d152e6950f7ba769feaf9021ffb4c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'deb8f1734d9653d7957de7c5bb963d64',
      'native_key' => 8,
      'filename' => 'modContentType/99fa507f256921f47dbc44ace85f211c.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9c0273b88e1734d7e76e0b52ea22e49b',
      'native_key' => NULL,
      'filename' => 'modClassMap/6af87b7367c750136e41d8ae2b13ec39.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'facc9d6fd1c0c3b1818a7e080fbf53e6',
      'native_key' => NULL,
      'filename' => 'modClassMap/904244681f46b8394b84f65f3a8b981a.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4eecbc756405387c34bd54fc7b2ca851',
      'native_key' => NULL,
      'filename' => 'modClassMap/7960cc8c5b9cac7e576f3125ec0ae11a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3a1536783f43b4d1880d8cf8ad060e1b',
      'native_key' => NULL,
      'filename' => 'modClassMap/b7e0ac8dfa241db20d9ce43a19e63057.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '59dc0c4319d5812d1d5b3abe532bc9d2',
      'native_key' => NULL,
      'filename' => 'modClassMap/be479c76d2b0d29af33b0dd1a3360e4d.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e8c2aef84f527e3b97a3f42caece7c61',
      'native_key' => NULL,
      'filename' => 'modClassMap/318a97a3d184ae2843cbfa2f00b0589a.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '61ace7e88ec8142fd30abf5f97e2eff1',
      'native_key' => NULL,
      'filename' => 'modClassMap/47340e959b9d544c665b34c5379b0a29.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ea8cee5be6e12b9d0c26a5e07496b35e',
      'native_key' => NULL,
      'filename' => 'modClassMap/e6a482a7e983aca661258907b9b03ff4.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1741f3c39ecc59d240a32322ff8f7cd8',
      'native_key' => NULL,
      'filename' => 'modClassMap/ac7fe61eb928d6581d7ca3606eeb4256.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4fe8a02cd80e0a01acfb669795a0da5',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/f77e57691c66cc081778f60f892f2eb9.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce48e7fc3d80a04687f61a7d84bcd3a6',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/6480da6bbbf11a48b481f64f6f9a8aeb.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59ff5bbe97d85dcc071fd320fe192a80',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/195015f191a72c378e1c3898d7252c22.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bac3e6640ebc1797a2733d76390a320',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/46783ba5e042c129c6ec72582281347b.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2986f03cdac5e0c06e17e24f97e74742',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/b1c3b4bc0b837f76f99038991dca5c3c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3afc18072316a13d0699275c7f599afe',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/4fa58f895c9170730c3417b8cf779f3c.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c80dcef8824740879ee9526e04d69738',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/7030bdcf0e72ae5fa0925a2f277cabf6.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '367ccb10aa39b0f799a07ac8012205db',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/440ebcbe4d568b2d648043622df8245c.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c3b97ef07ae059f5229f590afd85038',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/862ebe0838c737abb205d537b11af11b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2d2bc5a4f85e661d5c7af6d63da05a7',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/1c7b2df6b6574020457b8f6ea3c9c614.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0aaf035e9ea53114db10f22410d39240',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/7455ce7672cbe66adb9d320bbd376acb.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0409de8341bfb55deb386828327f3801',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/759a0d826a09f4233d5cc99bbf9c8491.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f36adf6e3ae5ecc8d90f90c7fbd96532',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/f910b0d8c93fe9ceabfd0fa2a8d8f473.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3ce05d838a1256c824e83b592aa9ca0',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/751fed5b2b1d2c0a45a73b7d784487d1.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '758de2e124fd5412f1cabb1a47c6533c',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/476ead74cb8b37c6b7c64d1d32133098.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4534fec57e6cf94a611bdb9034393566',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/6f7828cf0bab68cdc819c45ea7c81a75.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1b870eea82c8bbf9935ed970aaf8c7b',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/ea5513c28dd50459ae53ec73c80b2439.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '615c4fe67310b73619ba8dfbe67eba3f',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/b5b7f56b4005e771f285f26c3aecd64b.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e9cde1bac5a0cef4ba0f794e82454db',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/bb60c3669aee0cf4a8588bb24a51a053.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95a297e24bd8e54dbecea6639e334e07',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/eabc0732c42202749860731a36cdd7d0.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2af0f0d227ad2b42fa08537201eda2ca',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/bd5bb209482248933910e3c97f2a89b6.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05f252b46702d74e9ed78bc369c02b31',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/af661fc6f0f5778e5ab155d0957bd9d6.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbf154998e2d7555eabe857da19b0a4f',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/3d77fa6b15782c4022e69ba9166a6679.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c199ab06da7ff98b1d244053edae9315',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/792fe7f6615e40cff3b840f932b3b20b.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56ccc8e250cd9ecf0242cd6eda06a5ee',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/32587a3ef06add26df5cfd16586e0c09.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4fbb920317b99c42225f003c3163643',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/2dcae7d00ea2f16de97a2e98f22dd4e6.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c3c758ad5077ff59bb771f79e7f0bbc',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/ca30c06d8c98cdc525bd74fcc3cdc372.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe6360ec0a3cf5492be15acef341eb4c',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/9ce71bfb72a1495f1f13eba69536ac27.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0cd9488bdad370ab9bea7e7e84d0dc3',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d377b0f3f16d3743040b239fb6e962a2.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feef4e451798b1430d353799772af7f6',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/b2b315b744fb11c783c32f8d7025662b.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0623613ca02c39f7b15a6e659ce9508',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/dbdc00474c2c1d474e958debee7f8c22.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f6f6641595c820455746882087ff2da',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/c1f792a633a6505a343f95961c3241f5.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c059e4c9231769d62b05f2006e42e4a8',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/48512bd565a92bb3f2de1fed75a65676.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b8dae80bbc6d628f6119550ea0e4b78',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/066960cbd4e54f7148fe07b6f0f50e5c.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cc4799503b28a18ed7be617f1054beb',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/8f39475e060e02a2b7b27063a578cc6c.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d7a5e731039bb2acc11e92325fbacfd',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/7b528e8401b8965feed9b07552e3bba3.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '229366b29e940508e5e8085fff72568a',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/03b8b686d1f2d11ffc1df8984d45854c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83a235d58bdcfc46e0499cab23316176',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/4fc2edbabd101f6607c40d0c5419ff23.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1021ba74def46c1b4b96b6779d90f702',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/8a4f79734162394055c936ee82a8ac11.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0384b9f55229f8b3ecddb4ec66678a79',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/4a2663a91969f47ef0f5874be34e96c7.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bfc2a723e66f75e05c6bf601dffc9a5',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/970dca7776676db75b7f16a5e1422fec.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a3d5ff834ab149fc26e958810007279',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/a4f5ed290c0fa02d320a55acb1689eb0.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1164fb19d3d303adb7a1233dd27e781',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/46b286a8dac019d8fcebf1d972cca250.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7484b2fae3288905a0a1fb2069e6d248',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/223a9c84694bfe4b098a31825a76774d.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3481feccedd6ed972c43db515c58743d',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/008f2fcf468a6986b73d8eb9e2f5dcf2.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01754cf1bc8cf57c1b41300ccae4b38f',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/3c93b80b9724db326498766d3d75a81a.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a1e7fffb7c0f0fc8b62065fdf5c885f',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/5b0adc28a327673e29df45c8ecef2c81.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76aae89fb61d601da941090a5d283b0d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/eaf3944bb616f5239b18761eca85b930.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ae38afc0f3e8409dd7ddde8f28bcbf3',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f5858d82ac83946f341c1b34603bcc2b.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1716e02776c6a9dee5a293b979ac300d',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/9834058caa473092e3c3a9eb2b6b0c59.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b67a57fbf8e5e42a274d88b1fe3620d0',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/bb6621b878ae35019be70a79aebf6d2e.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f25b548e83a5ae66338dfdba9b06ce74',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/392a1425933d9ae2453b2e737d7587bf.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02c9ea9362227b52447bdd28f25b8304',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/c178a14b2fe5ab7cca21f8024baa01cf.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8311e867e1fcf8c7b3ec8fb3d2f53a88',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/e96a0ddd58fac012538ece9f33b89626.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2a10deeaaa749a6aa52f26157ca0c22',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/51a9d9ae7e2106f70f2f37531db18c8d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcaa66d010413b2862849ad895c4d28a',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/f63223cb498d1202d18e87b57445bc16.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed4eccfabbdbe6789f69235210a0aa5c',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/846dcf853398057fa7b3a07df17b53a6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c1b2517180b8ec81bff293f4a803fcf',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/4e3f6e5198b85bfda210c4c378bf857b.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7b0325c30bf4f18f4d7010c2b38ae90',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/454754bbd8c3560fe64dc9ff6ea403f7.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5ebef58ad36dce96419e60349922ff4',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/75b309fc6247367224a3fd0dd3124a35.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2af8a338f1cad066e799b8cd8de73099',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a8b6d29c6bf630918a0e1100e1f78724.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e9cadf7dfaba9eef30104afb357d08a',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/4be33b28422fe9879870cc9d353af05d.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b5a0e0ee32bbaf7cea0fae3781ed4b1',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/07164ad60668a3f9158c2667b29faad5.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af38e72438bea7ffa24d3a9e856b842f',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/3f7b07b38ec18d96939b52cba21ea73e.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cebef81bd75bb8fd277864da050d9f26',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/2c30139904b1349b9b2de10dcb763450.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bdb7997d0e038269e84c3b85f4eb764',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/13973d432dd411c1edcc57811bf59769.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea3104d287dbb1da39b5c2ab2f42406c',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/c11c3e88d179f3099740f7f118212018.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4da7f49420606da498a78dc4b0c6293e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/62b67e645d1c348551f90f59d2b32187.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac7300ac02140e9c01c46a2ee08e5e7e',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/e47a6789f9d3e604a1eb359ac049b2f6.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c3b8f2bf4ab4bacc0bbae4dff630626',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/2ff7f1a2ab16b524da361465e1bd7a08.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdc5ff5723371a41880e93b1b7c2a5a7',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/049f89d6a5ba776ba77bc826a9787ec2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33944b6cf7ffbdb360fcbf132916bf57',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/a5c65d6d5b9bbe07e15a9ed9219a359d.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b4d0ac5c22215a325ff538b68ef0f64',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/83cc31709d1f44cf76f741161e487a54.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dabbf8c7106e4dc19fee9eb09a0e6d87',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/83dd8d68e4a4433807562ceec47e2e45.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2a2528c9785fe9da6323543fcd5ef69',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/4a901f1e49a92b1b258730f87e16a335.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e889e48289ffa518621bcbb218b33153',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/2207a1df85051e00b6bad3d848df3aab.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdbe74d2b2e11120e39c0bf5b7bdc010',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/36706af383d524d013bf9d9edb96eed3.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb4e080bdb453b39e98fe0a38fdd6545',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/2d45200f3ebaed472201411149ace12a.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d95f15a9aa751159fe3b379a3aea58f',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/0af5e2f895ec2c5c21e212f4e132d553.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35a68cce96a962a148d5d76316a0e968',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/30690fd180f2eae4f5a2d815db7355d2.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '768d75e6f508bea96e3e1af3faba07c2',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/1f4a683584d6d98fe45603a851fd57e8.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff39558977495cf6852c46674fbd3219',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/6b3cf4e56c50ed5ae6d7c7a7bdc629d2.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f848f783ceee42c6bfee469ee132a123',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/22a5de41566f47a190f9ed9f5d56a99d.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f961006e672428e5f26573f1ec264ea',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/0a73c9186123a356b56bfd7ce216b9d8.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30821e82f0962cc8b7b3796642ff198f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/d5371dcb6af255ef29150c9dabeabd57.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2c502aaf3f871dd7a95e63759b58d4f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/f650fe076d52c884da370d25e5f6b131.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e5b59b882fce4aa6d6fcdd4449e2cf7',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/5206c782b54ae0cc61ebebc1897b559a.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d75d2bfeee596796db4994fb2596c63',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/008dc6187642472571f252b1f20750e9.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '214a6abd6636a28ef2540f6ac1f3cb88',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/88f09d40c49f783a76cf36d0a7cc17fd.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '695a0eeecdb8996a8b334e7a105df678',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/e6afbc24abb2de4124e1699e3984cf2e.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20b8a7cb20a76221e70a3a44b4366f53',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a1d9415648472b9bfbc0d5111f5b000c.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '203eeb605b1ffcc5ae38edaecaff632b',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/2363b6a4779aeedbb2c61986aef60251.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80ef318bb5abef558ec19c685d684f1d',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/95e5fe5f750f73551ff8622a9f824cc7.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3316f584275005f93297608659bf9046',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/27383b6a95283c3636aa42a0200fc779.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3086aad518e21d9aea4b97714f8f761',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/a241b066c9dac0e6304d681c5cba6086.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '909af8871efc2c2097cb7dfeb76fb292',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/9826e1f98fb978f9f8a179aa51094190.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdfc53e8956f35a22142331897cc6b82',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/da14718b5253776a294b1d3a8c5b7647.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e5872bfd7512e8bef8c5cc0621f8f35',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/5880e7ded378f6b29436023ff63848ac.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc730458801ce05631f23e4e4970d4a0',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/5361e532c0a9bcbf2ec121386e35bbe7.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4659ca17508ae2e76e8ffe3ebe3429ce',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/65a1456298485bfa42b4fdbb28473956.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e94e180beedbc14e40d7bac0d2a567ec',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/ece34c6b4e706dc9495fea1e08925e55.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b998417d8ce3a4e93ece764fb345e7d',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/4b8384a3fd8f7bdbea98769410809c6a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aba276a36834b847814474f4a816a3ae',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/6a42d0e35633ca65eab752afef1ee5a7.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '172e2dc5ff85254d193fe39450384665',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/fb9822da13fbf0f3760d3fbcedc3053b.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '537d3e4309e4a78c9de9abcec7ce8e36',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/46ff61c8da3b73eb6b1793795df7e75c.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0832da46a2687b11ccffe40b70a292f3',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/5e03861ac597c352cd542f97d27c8b74.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72ecd2f3070019ad5cedecaca317e1fe',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/7c7d5b076ee1b0448b1128a908e52865.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc1d552a9861f2db902413925cda296f',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/1c0dbcc808974db8e4bc9294a7f1322a.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e2d2dbab3d2047b4af98284a543f494',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/0e6eab035b2f0939cb0ecd77a72f6b5d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5d6ec6b8f7dc0690935e31d320917b5',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/113f6f05a18a8683aedc80614ecf8dfa.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e87a6fb3b9d589932951e75edc6b41d',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/f3dd46e600148e5615d5a5560a774a0e.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d48b5e802c33bd50e56597cb5207c2f',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/7098fc8009d9951f6cee05740cb2eaf6.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6451c661877310d62c27f0dee14e71f0',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/a5b563bd3dd3f2e340e5ff5f91e884ac.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf1817fe84c3e22143d4c5542fc7bad2',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/2fc1028cd76411a24db8a59abb0827ab.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db515aa2f377380060a2228a54b234e1',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/492cc3bbc3e23bdef71a81d7cc14d8a6.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4726ca798ec4da36c9021c23d35472a6',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/e72fd9092c6cbd07985c1089efbae310.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01fcaab8d53c2b461d6a7575ff6fb106',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/b40f368c04d248d45ab406fc900ba9b6.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e173bd70e44da39c0efe1cb3dd7aa5',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/d17aff7c1f5f449b5bac5a8e1db05260.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5412af20da2509e1154806586e663efb',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/943d52ec9f8e1990c3be3330860866b3.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '565018440c7752d79e23b8479fda04a9',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/59c2a9f2a5178758ce09cfd83c963337.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd957f8be12f047cfe3da7a0873ca81f7',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/dde2df6da6bd70118d495b3614c4f4cf.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db01e511931f88527372394af2e9da75',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/b25f4ddbac8eadbe5081c4838ba9afd6.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '172e19059f9fe928e623d1df2bb0138d',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/549a48ffe28b6e11b17a127647fdca0f.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a3cdc15fd47c9b2d41421a2e944a9b5',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/045e7de8c5dcb2287f410270918cd9b9.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a7bb99ea391fa80eec91cac5bf25830',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/ae2b6159c452c908a1666c0c3905e424.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1aaf7eabda38c3ce889199a25e61f488',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/ca41ab6a473a39edc33a09d01c99fcf7.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c7b7d1d35a13f4c4b744f9fbde422f9',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/c8b130272424ae7b0e17d3e872bded4a.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4e0395fc8f19c30fc49ab1dd321cd38',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/8f9a78555f8cc74d6ef8e0f55a2b86cb.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a260e1bb7c4bf0044f4f9d19e656a4e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/58f06f678220091cae503bef765aa549.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ab31a254e67c9c41f1a7fc2656d630f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/4fe781d4e570b8081ceeb8177ddd4c8b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9712145f6cf839b991092be338951f32',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/c9a7fcd6a7fabd5986f45c6b26239200.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17c1988e3df40161a1da5e88747af9af',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/dc2cebd53da860873a90ede18117912a.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bb42beb45d619e2e9af565298322609',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/a86090e2920a40dcdafe0ae3e5760ab3.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '412db04d8566999766d6aa5d55f44445',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/d80e5da7d48c0562d46f0194f0d780a2.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26c25a95b678279671464263b3873333',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/d5ba7011342de996c238347ad55b9c07.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ade348582094fcdc1f6cc454a38020c3',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/6006fe8ec301c75a8f3dcdcb28c403f2.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02ced7d5739f190053828e89701115a4',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/32cca95033d0d69c0c62dcdba82a04fe.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9a5fe463087d171f24dce481fe0dc8a',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/43f9ba96e1b5c6edf421b3e7f7a247a9.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbe17a3c21980bc59e9bbdc7e98323c8',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/0f52f995d79ecd6422a8a3f35e505874.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c943044f0e8e622470fe87686c0acf5c',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/b5144f38fb277ad45cb7f87df203148b.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18d7a17c56ef89eedd67baf6b57d7c55',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/269ea7da1797f0648b602dc963d82f46.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57b59d86562a2a5d29c9d6f7858a7d18',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/f5f1616d71d2d91ed47b58a4e7463caf.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06c872eecefb947c4ccc8bae6367e4eb',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/33bbfbc9657615b340507d0c5763a3d7.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70f30776fb151106076e283d0b71a412',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/1ff06b49991f4ec56f431c83b3d66c19.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eb90992998c62fe26cffdd40df2b2e8',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/edf6f0f1b21b6109c3ba736a4877e141.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3cc50255412072e9ea0738713168e11',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/41a28621ea74d538b1eabeb823f79590.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70893a719c48ea9c77ae5ef4c37c7493',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/51dc795e36a01a850d41535e921f4741.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43c365bf64587e16b3d1d8427f20e804',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/40af232e08e9514fe801f039c2427cc6.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc92f6a23f203b6d3e102bd2c4ec025f',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/b731326a427b0adf58c076e77ec4193a.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dca662ef7d8ff30cd3db7c2e4bb3cb6',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/f4ee3de152b6a9fcaeefdb945b987e80.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d7fe52a0da78ee01af96e2dd8ec21b',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a50d85fba9a825c99d09e29387c3d69e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c079e4d199488bdc3c80c1bd3c7498c',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/aba5dd84e66845cb1aac64a66d6bffe7.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd6f34456cdf1468f8a405902dfcd884',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/24a7a2a7358cd0b546388f0fa528b2c4.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6421b9617e4dc6a3bfff163257683a7',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/3bca93042389989da33842170eb08436.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3e27eb32377758f119fb42053df9e88',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/958cabe2189dd20e4e6b0fef27588333.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ba9aa053fcb4d560ba0916068437275',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/1a41c8ad08d941d4822513bc3ac5d435.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b55c900f643452aae6e086b7cd22ac0e',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/47927b24fee8b765935f73db8f2ec450.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40d3b6921c87275848eb45ebe39b9ed2',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/3630f715f5d7956905bd69305503e399.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35e27a4e9e8fb1c83e160413ce77dab5',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/f2b10507d232570cca193d987879958f.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '069c5b3adb19ba2a8664f727448c8a3f',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/8b95118df058bd2895ab3436b2df7645.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c89cd7ce9f84e32b350214987cc8176',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/56e8202997f909f8ed66cbb2edeceb77.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1571f2e265e8bb11a5e86d66c57d5bf1',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/32bb53a0f5db1669d0a3e6f2b6eb7b20.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9febb92999bd48736cdbb48959ea28ed',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/baa957adff221d360db6c6ba90c8e230.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '084b7f57e878df9c2e6e8039f3138ad3',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/ff7bfd6d9ff9dca9b192bb62a773d6f8.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '288d39243b38066790d81751f32ec49a',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/48a61f11b0db8a8b1a2ca476118517bc.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1556fd62745d17e35c26a94b9b0579b4',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/95a70f49b330fb38aa92c23c45d2499b.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31efa8c01cd958757b24b709d5c4c8c9',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/0db15677e2f8506e5934b010b75d41cd.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e62cfc83dfc528af749def3168150a6',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/6d281b875c944ec1d87e5e777904eb4f.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '779da6c7a8b3c854cac21860cde60610',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/16eb7618560dcc3aa88ed1f2c8affdeb.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81cdc8c0cf1c2eaf22933bd4899d6532',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/0ef2ad0e22597cffc1964508760d0fd2.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a4234c857304a922f46e1fde1e862fb',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/3882a6d2e371e9090a7ef56bfaf3505c.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0222a22bf90a5bd591a89f1005a1a034',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/92d294ecd267e3cadf5450595c3596fe.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '050c7470147e13e632d7b304d1441700',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/812315035a2bf60d5f12dd9c469394a8.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67ed3084a4fe2f9fcbd986b3a7a83532',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/cb0edb44b37b87d6a319b02bfeaba85f.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55604a321b37de159dc4df48269d00ef',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/baac6ca336fd2dfc18597563c34db320.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd39b4e08e3ea23780328199ebb2ecd53',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/68b45fbac4d039f02667d331a57ece61.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '765dfbd1abf17bf319e263ece4e3753b',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/53a6eee005f6ecb2132f5f09d31bad37.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dedd2d7b79b507812b7c1445013df52f',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/ffe598576827aac4f91f8aaff2624bc8.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5042a80f8ed3842bac3ca65d1f02bc84',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/5e0f3a707a14fd61c793df658aa0da9c.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '666b12f8cc053e2cef1bfb819f7546ff',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/320a536d91f96563c6e7319abb1c8fd0.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '884f9ce73ee3a153655b0263923b98bb',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/609199dc27596a9784b4e491bf995f7f.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592a3239ae8bf7bd07ba458b348f65a9',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/f9a7a7722c7045ed8034392c7ac965eb.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9df7af931b7aaf1bb2154a0adef6618a',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/8849ee06bc6726f9858d790898a0eee8.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f7b355fb678ba849c2bcef93e8b08c',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/e0dd61bc082e47b8c9d3bf4b3a74c05d.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e84160b810a3fe9b94e83b2a97ec4673',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/5585d0bf113471de0976901b0d4c7baa.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81af87875ec5ce0a7a0453b4dcbd5061',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/9c4147245a1375c42557a44dcf41c089.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '596de149a2823311330c8d6523e440f5',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/589d127faf69ed813a8bed75dd3a5b9d.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e53a4d05e327207dc77ba3553c1c3af',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/4c11999834d0dfbb33f46da1d3b779a3.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ecc2fa09144a3ac08b5f413d21e0710',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/53a978f1dfc3bb9c362e3729a21b5888.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b267ad79f3299b2d612df0bd1fb0ed38',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/1702022dfe3583af03b9d59eadf426fa.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efcee0fedf719e3e9cfb058152152351',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/75b9315d1d66e92b998e7bafc306800d.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2014133ee6156b3503fe3aee58fe3d07',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/f80f89e7d8d3f573efbcf6a26e2bbec8.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '904c04006a0447b7ccf791f395c95479',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/0f9d160577891fbb0449e5c6f48abe4b.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d203890e81092f3d5db51021f3febd9',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/5c0fc35b65d243dddd25ece9fbd800dc.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd078b67b4e79afcefff19443edf38b7',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/2eeff42ef45d6cc76ff119e6f6ee4b75.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f557466e7191096cfb046473e2983e8',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/8f77a444ad793b46196d9d1edf573c7e.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b39720c8808822ec3059c12d15454fb3',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/3fee1bf55d9e05e8c2a1ff9447514ae4.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '285737efbc9157f8d6fff5c0c028c2c0',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/429654d6596bee1fbd85b7fdbf87eea1.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '656b0f67ca756d8125299bfaab7bc4fe',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/e1d9c7111843ec1e90b5b96dbc2bfde1.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e52a82e88b221e158e7318cd0f958344',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/94ec8b3ee7d32cee6dfda56dd3ab0829.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fc16551872b3a5fc9e10182a1627e73',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/381288e9addea5c545c2704c9ab218c2.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed9b5825e1e00323a65d56649f288d6b',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/f4bc8feaa5dc77fb543ab09f7f78f98f.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f335e20bee089686e5a78e554ee63b6a',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/6d7f2d9e359cb82bb559d39e3e30a393.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '915206623117f14ca0a404c251be1f7e',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/3251b6c48f5e46fe50f0940f7b0e02d1.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e854007b9e910a67f2bb6ca7c3472a4e',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/94ca0fad8a931d602d0b906a7d4339d2.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccc8733c6e79a8df167b3fdda0dc10cb',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/34f3a464c9b6156bd960551580707e0b.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51ac0a8e7e896977412a0bf8b5e328c9',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/f6ac8f62ba548ea1238269226ef373d6.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc7a07ced1117305a0233369950a4318',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d2531e1d7abb0cefd774baa3a81be3dd.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '319aac794a758782f4e80e907f7c1dbd',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/4c81580f9a70639f261a9619295a7575.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42bd6fa5411a40b40cfec41e2a75eead',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/0eba24e63807b8d32dbffc4005659263.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df7e1499f792e1fdc02fff86f058a13d',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/842a5f72fa4efb1d1b4b9a83e7876c89.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e2c9e02547fe74b544f5583634812c2',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/69e39fa5f0ef7c390432bef4a4ed8a66.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0fcaac55353854a2977092d7480bd54',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/91f7ac31ae408bcc0029830c95fecd31.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be37ec6830aac3c915e609d3684fad82',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/1cdc91ab133e1c1188d3b9638fec0a51.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '939b353a8bdacc96fa87308ca0fc40ba',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/367acaed386bbe4a1991bf3edd58e804.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88e8125deb65753ca806836dd32b6e2e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/49a043e1a55b936579e522dc82db8e8d.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2712895df01a821ab4ab41fc898ac2c',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/b1611c30747ebc923032e101f710f5a4.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48b93ca865bb1eaa9ce89ab94bd7d07a',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/3c61492e9d38d23913596437b40d9d5b.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15cc054f2394e8d75a82c591222c5a9d',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/8d529857942f826125a2644911e0427c.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b558f4d8c0761ddbf7230ff1fd9081d2',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/22127e9828105d1139cb27a9eacba203.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bffcae18efe5be6b8b742d28f32bae7',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/933f76172614ebee0c437fd0390f3c28.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa0dc0f44176b3bd955e93fe216409d4',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/b38756834590c1617a9509789bed39d2.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '974d8780cd65ee447fa6efc5acf0ee99',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/d3fb77098baaff02c1bc3c98e757b674.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a530143c88f29a92bc4132461695a99b',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/657a83e05f360b4fe4b7579b724239e0.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '803fbef545d90766501ae92046d8f383',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/32d3283a6da265cc7b3d66921012c324.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cb99272a224a6bc779f76ec5c675ef5',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/f74d9afd9d264f02feb785294211190b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32f067b6f8df4286766445b14608eae0',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/49579686ab888fe9f64ac18eac120e64.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70def06323df9f39746094948be2bf07',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/2ed37b3594f1d697f1106abf8a228a35.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6449b23420cdf4d5835dfdadffc0529',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/4c876991eca5d2a0d226e292548bc280.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ddf2945fc6633fac1835e9370978b6a',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/fe09fc28c058c442ebffc50bbdf7760b.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b8cf902c1eb149899c6e049f1a1108',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/041c3d669ed6523745c4b31d1b838568.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76a74e85458a51096a2beef53d64b98d',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/60db5f77e634ed62034aa3e25a890c7c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad28e9ad44a0af1c96f88cb21472c734',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/7c315088499d9b9728162b109e886a11.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e072dc6690fcf23e5cff476f9f4627b',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/06d09b7b9b191a6a90a5ae14bc41ea4e.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbab07a56a19600ed01fdaf794032daa',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/5722eb908f73a32e8edc6efba371b3a0.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a8a22936b7083d31fe1832b02e36ce8',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/2f9463c56317a9a9ae56ad5775bcb2e6.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46bb02fcac96022fbf2f170d170ba7ad',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/be8657b995eda1eed16298ef7d34b45d.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb5fdf485b891c885415ddba824fde45',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/0eeb71516f67c06f14b0fb5955fb0530.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea4892292113af3cf07e83d03bc4ca27',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/329da39cf214d262375dade777c1cd39.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19f49ed75d9d922e12a3eb823fda12fe',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/283031f84f64553526ba214346cf5333.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26c609cc9e0d958919fd30e94afe1ae4',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/88236646c03e4747b8a477e78a57906c.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0df317a2f700c42f578c1740df1f882a',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/bf18d6d96b59038973e61047e8eabc75.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f85e760338f9f99e5a09d1e938491a7',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/3feeb8cd0c05179d76f13806d799cf29.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fef9d7abbba48fc59006e0f5e04835d3',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/d9ff4956819bbc0f8b44fbc53e4ca0e8.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd55d2846dc89d8ece15d8f3774967b0b',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/ef14d213c4e5b8f180880641a4b51ffa.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19c5a49090f5e57fc2d08f637a94e049',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/8fe0b28928e84ba72e557e4e12273c84.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38fbb1167f62252074653d4854f4c6b1',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/0b0bfa95ae003691cd637dbe7d618ea6.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e1c24af5ef3ff039625d81b4f152624',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/8a5f26cc765726047b81a9d224247f31.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e56b283e19de9aee554b1a75ceefa38',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/3361e5eeb54dcb6fdd87f24c70205ab2.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b989e922ac1b20f23255b592b12216c1',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/e87cd8d392ba8f6f6f8ce0d74a663639.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd64fc4ef9ef1437d4c01f92e314b947',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/15ca72e1bbebb2e79334319ea2a555c2.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1a77311f835db0d5965db783189e2b',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/044fe05292e356e8b80784a4a9a84d13.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2999a39abd0f419f46d970eee8391a20',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/26faed9ae80a6859da627cbbabf2a3c6.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e96bc447adc60a6bbf92cad28ec36399',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/9a1288fad4edb7224b49b4480a45a472.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b196fde3667cd0e832259148f215bdca',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/e2f5ecf457e014a6b6d95d3a8036a68b.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0a9a019dd705d34a621bb05764f7dc2',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/be0bdeb487551f28ae8eab212eb72486.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7369ab13a9fa13ca477dcfba95f8a522',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/f30b904cb6956487f45bb4611bdbf088.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e778cd7980e7a48cba15fa635aeb89f',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/9e644a394b13bd81f774919a76586e38.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b71f0d3ad1d915929d93c0d0e77e639',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/ccbaa58116c5942b7ab456e49a145997.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b108e86f3c29f59ef5ce5d2f463556f5',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/16b4dbbb5587ee221508970335ceac9e.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79a5d1915a927c6771e64dd5e8ca24a4',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/3b658b3361b1d094f603f48d93ccc3af.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ae8b508a9f13d420fd722ba8aa9eaa3',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/fcc9ef39376bb4e513d1266593936f90.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f074906012891a7300cd751a142aa1d',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/8a0a36b15a1583923548ad78c1c6e8de.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2eb145b85b3187de47571c671d4b1e97',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/a5be4cb22b6bf398de7cf57b903d68ba.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec464e235983f90aeeb0ac277ffe32bf',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/89f4a22943adeebbeb97fb2b016f1ded.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e538fe81c3e8adda0d666af01feed255',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/a58369b96a7e3a37553ba01eeb930e44.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33ef38a7afd12183066027ac4cdc9931',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/86abbd419042c53754aa8a03b1dbfd76.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19d91dad5206ccf0154eca956fde30d7',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/1cf3d0ed95a91f1e0b53e44e06022290.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5a9080f972c825d42062af951401073',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/b0377bbf600088b844377e801e8e4e16.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a498864ec20690aed4a3347dec49da9',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/f58fb8eebf3163546ba0145684254ced.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f686df03050c347b911f1b14f718e36',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/529ba5353240d46471d098bbcb548657.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd13f80a922b5c4ff35897d92cb7cefe3',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/1620cbaee5d36d46135277be804e527f.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a05966358804c887195d44f3a4ff12b4',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/e6d81af0e2001f80c56d41a8c4bccbb6.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '888bba4010c7f77c689faf59e780b1d1',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/f91366aef1a45f4dfa1d64e4a0fa261c.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5bd4501fe6dfd6faa3b5adbd69769d',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/9971d59e15e939fb811bd03158c18898.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d692c2d783a5c6746feaf54c914494d',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/4167203370cbdd4e60c75876c0384beb.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beed07436f1b8697478d8a03bc63f09d',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/28d8e9ef302e1318f7a9c7013b98a50d.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f132b8746222667cf6cec123b323e732',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/884fdf756388d372f27f2c146dcbe634.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41426d138a35139e92694023f61c692f',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/561140e2a963de020e03ef4273885148.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b982e8d9e1e85dcd80a9e4bc9cb9c302',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/3040fef0f8809c162570d0d12c925cf8.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39d7256a69c3f250c0012a49dab9db8f',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9dccddcd46ff0c1bc6f309076c0b2d8a.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b197da8e3f7aabf6f4020d431e5c03d7',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/c779c1961b2115e8f85bb2cbf66856bf.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b37d1cc705504788443c87ac071b6541',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/3a4d47a6ec17cf533b33ce85a4e8e8e2.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b920b2a121250588db91483be412c35',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/05f653fd5cee05af6cf9b339b1555dc2.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd158895689477b4f69862b6653d54f11',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/1e58ec7f02a7283917aef2d1a0c98697.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '742a92ba845cba54dd6b831dbaaa3bd6',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/7aa83ca426c649aa40984f0d65d02050.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c07516b4716eabf0bb4e99a98def515',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/27a250c28dddf3af4c331b6f6bcd0e60.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88b8f387a5d166377fb092db05d88054',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/21ee388b2f32094f6e0aa863aded4ccc.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0530b3b582f983400e5dd3d0f69efa4',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/5637ec1562f861db16331de5f805a188.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c991bc0ceaf162327267e4c72e27677',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/90ece34fb1c2e155e1ec5fec028d11f8.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d0c38d4fa1c863b2c85992e4f811a0b',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/961ba22d1b2027400ee7e102b3b9f86b.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba3de28c16cb08cf0283b1d357c8c486',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/c7f9d6cb46e5c5e2418d7f264d8a4cd4.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c0e079ea41f230b18ead554203062ac',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/29c2965330ecbf03b37a8325a4fc39a0.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb67d2ec733a78f4e38418f6a27c9a47',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/35346ce6cee77b51b7153c5c08ad1fea.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a141d0a8b1d1e7e88545c14d428c36d4',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/6fbe03332a9bd213e2d745b0cea228eb.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f6e5816e1650853267a1b8a871c535f',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/86ff6d4c373076f245e30258a15aad03.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b97b70d527a5982894c6c132ef706820',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/b4e2644ab0d4d24394331867ae875a91.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b24229c78e558f543dab895216fba37',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/99903e2282298d47e11d32c9ace536a1.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43bad62a7784a931a0a02c93c5173fba',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/726a521f433236d7794c473595e874d9.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9533b598c0c3945ca78c4ab594ef903',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/9ce48978eff67629f30c49d8bfac5fa0.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4d60bc05d1e1b06706646b5f3101c58',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/3e843233ec791a73b39e998714daba9c.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e9cf47278ab7b7e2432b97c7d6e70a5',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/8644fca8ba952d7cef88334c3262458e.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03b16d6d1849911f8923908f7b2720d1',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/712341a86090c46e7db0bfb7c0a0bfe5.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20cf20f055b9d386f9e5918e6cfdf4fe',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/0eb8e763e4eb83fec243e70ffa8926ce.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af590d0a6e93ed0ad8f852cf96d237b7',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/70b3963afbf85f1d2b83be18cda33bf0.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '307964cd972ee0b447c8bde56eafc806',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/3631c710aea30239009fea06b9eaf18e.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17fdaaeb2cd08eb1368fa8584de11daf',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/1910e2386579a85644a4554e1c54dc07.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a74401e4224ab5bcfd2d2060cff4e76',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/7b7aa49311efe29c4cde41cc1dedf8c2.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff4aadfa9709e449a72bace501249c98',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/9d8d2f712d543564a4a499adf56c0ce6.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '081bc13e0fcf77dfc85ae7a73a1b934f',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/8bf627459a7678c2f945ad572d2d09ba.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '955300f39b6e09bebeb27ff38e438aa4',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/c570d6aceb36c02d2af4ea196a7c6665.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '869a81f51fa030fa41d2605c6b1dfc5a',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/792ebac099458dba32655b8fda86be05.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '341a42ff8e0d5aebe8c7957a9cb39466',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/e8115dde60ea90da9a439d03e2fc0ab3.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ca23072ddcc197d1dfafd765fadcc60',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/8afcfa21317256e125acbec302d9db42.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc0ab1adbebb96626a05c6c44234a4a9',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/b26f5193f22e20fa5f0ddc7860c7158b.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64c4fdf1eee4b6b421459abdd7b7f43f',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/7134825506734cb4c43b22928c675d65.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0724e27bc49fee46496875661376b12',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/20362c8b7a95ae26d40c01f98030e29e.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5cfd1c1e32d024cb982a84bf113e4d3',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/60b009d2d953e01d183a4109da7c6697.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5018505720dbf02567b92977840a0b2e',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/062acfb4c7a350e9fa23208ae9e44a28.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4351457a2f389c9576369f8a308a1208',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/a6c270635f75720454cfc0739f113945.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1fe9bfcc49ba58cca19c4e2c28dc221',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/46e3001d9d94c7620031a2ccd81f70fd.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df8f5e063ffbec50f5fefb0d49d2da43',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/2971060c0e62d857cc389a62a4cd6136.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40ad1506d4d9815a188409b9866a53cc',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/4bf631f2673ef1572caabb761f3419f6.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abaea4c6d391e40542f0ac71d3c6c037',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/7f2d378a8769cbcb932683a56078e440.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98fa09ab5cac100e248f577f9bde79d5',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/e9cc02ab5d82eb2739af3e1b578a7e52.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e43fcd48c1b8a329857ca6f2c8bc48e',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/6fdd8ad2879223a18920d839ce095205.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f932da310de59697072fc16355cc40',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/9b39cb15444b3408adf2ee61e7ebc1c3.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aa22dcc24ee79e40abbf9172cd5f506',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/059a88da4eec16c13db2da7a686a5508.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7b24b09944ca1944a954b3f9d90e046',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/7a9107c3bb8dfe136b13f2526e1a3e3b.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84be357a07342cbe2059b7ab214fa097',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/3d1d96eb4d6344bb9c13120dcdf4f665.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0ef4d85d916bc2c1b4cb71ac90b89f1',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/f472288e95f94b38d65ee4eb1fb1f4e2.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4c7c5019a2144b380d02a99b204cdcb',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/4f2459273337f6e60a96636c06f28d29.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4950614b9f2e9d633cc1b901fec03dd5',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/a25f9ae4dbfb9f86fd6a4481e88648d0.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17fb0d89b96539d46cace9bef25a9336',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/97d3933a33cacf39c8a4646c817ebc48.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0a63e02b5d5d05177244daf0c3edf0a',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/caa2eb692d9ac6c23af28c8e6c35d97e.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '163c5c9821d5b222236aad028d3e0336',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/f80f6b2a4507528644db47e6de4804e1.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91e63902ae8eaf84671d2e201f325f35',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/a0a9048156cffb9b751dbf163c704e2c.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f05cb10e288bff1e9285825bf8bfa3',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/c556bc7c0bde8b499701ece2da3a9fc6.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dc4e3aa09f63e621b5b4be7165833cd',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/814589f3b338ae84f9e6c2ce2fa04dc8.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8107478133f8c5fd71f56c878d4a7641',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/542afd42183952ac2269dc5d332f7e1d.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5311900ba421daf6e5518c2b55c73465',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/cb26d8886d6a9c13fa0bf46798259d82.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0738d1ec2be99cebb2f5acf607204bf',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/6422d45e4adb492d8d5d00b475777189.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90f052fc2a9c6d6703e253f78039b7d4',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/c51f71f06a784316bb8ac2a4d0b93c98.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93c0397bd46d1b21cfe05c0a2229ca23',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/1f963b96b4a7d918541570a734427c46.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '026b99abc73bd0ca5fb755bd65fa0355',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/9a8dbbc9334691ef32af19552baeb8a0.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dda932352c1b3fda67f26ff9ac794573',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/9dcd69ab32cf8f4dc840cb84b9ba8553.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd57962c4197cd95ba2fca84b70c741d4',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/50b3b7d00460b8757309d2e07d222a12.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4abbf0d5ba2e9a04eba94401e045dbdb',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/8f4670789b9bb15a1cb7bdd2fc6fcd38.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b20a88bd1fd4d42a9b79517eec45f5a0',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/f1a6b334f507f393cc1f1986fb61d002.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ab5688050e488abe0106d7ffa131373',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/3b7eea9132d66d992475f7f45c78aa45.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b482c4c71da3e3a6df56c1f5819a77a',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/dad9a49f9dbb128cf6cdfad7bd12574c.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac79838c505ae6a230fd4a914321b338',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/b3417b4d0951608a9cfc9143fee4f39b.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '714d5291fd8ff2d967f36504b4087d4e',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/ab4ad4080aed0936ca87a6d8a63cff7a.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b8ae130e268bac2451ab695f1f1a2ab',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/b5b02257c34313642820615b09894afe.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16ead2950ae4d5eae1e3540c299ce2b5',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/edaf1c9f9fab6dacfc643f98d9412146.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ff84a058067da6052eda6d28069ff81',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/312fd1f4fa422028b341818f40562698.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92815495851f46124584f81a54983435',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/f6e1bb219f7d084094245ee2a0440302.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eb383fade901bcd2661f1f31822d11f',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/55c82f2830cd3ea11d9c41bac09fb197.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb791812e3522cca2d588c83d6ffe28',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/a90c2f51b24496c38ed36ef0511131a3.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ce4b8110b1b5c75c32700c725a424ab',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/0e5f66f4344c6dc9c90bc653a4f366a7.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e2b25f1eec68120eaf9cc77f312b1d9',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/0e7bf1fc7b8588339fec945ea604ce76.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4c05ee58a46c93e4eb094d04f49b29d',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/a97b7440b9473abe16d32efb4e144989.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7a4de595e22c14c97929f7a07b70470',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/e462d4a6202bdcf1cace2e43ff980bbc.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3996a1b68478e3ef78a2dd43856885e4',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/5272454aa9459b6227b4ec0432c3f5d6.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f6fc8b4abf017ffde973f8d9ec2259',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/fd7d4a6fcdf95fd88a6d8739d47baaa4.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f1401eac39d77bc8a4cae405d565a9',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/1be95881f1093b13132881b65db203bd.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3392827f4f4dfba3c2ecf90e276f211',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/368ba04407b57e5f0c5b66d910ba4c1d.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7b32225a5f46d55d1cd330aead2906e',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/4d873e3269d2ee9e701021c3c436ede4.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850a9298466942bbe099f9c857c77174',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/fbeec6478240951ec81fefa0240108ae.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37839e94f90f508741e3dc15a370ca8f',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/a909caed9c49dfb359731d3240964c15.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51a37d067665ab384db57fa0758ffbbd',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/b7672dd2a1c8beae8b9a288c5397ea42.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd5ea370e24414e7be25ded110e7ada3',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/b8efba3c0e0d17c642c48b86f0578158.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59228500b8bb9c573cf45f7a505ae5ae',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/c67668ef29596b7abde28a435c930bd9.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af0affb2411647c3219134b73c5ad392',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/3b41e5350b4ea32b4a171324a5ae431f.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4117b16104df746a1e341b0e0f59ca4c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/54ea04a6025621ad5c0ba31c93ee6542.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6de525df1e7e50df245d1aefff2eaf72',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/afa448958623ecf7f758158478b73238.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86b42324ff709f53a7e3d4ad7c5d1e82',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/3a8fccecb0ba0db45405bee3592cf069.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739781c7684d1c43dfe1e2d790f25e97',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a7f6b5c1e1b9320c88dffdb6974bfb90.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b204fe4eb54afa30e03b828077e27983',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/021870a90b5dfaf590c7033c3a0371ae.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51949d6848b5aa63f75458fc7a008c63',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/128483f0fb2fe0b553a9c4008a82eb57.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6085794ecde9eca04c63d479058a2c71',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/1695c37e265772bad2c5e7083bb6e27f.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dee225c4e83d1c1a2ce3755251b0a945',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/52ac181b76031acb0b9b3ab5c2cb113c.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd452dbb43887ee6b1d0e570ef0154b05',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/900688f2047f542320fe47c986a73d67.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '575b2d3b3f1dbbe27fdb854896fbc6ee',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/11ef69b68c2c189d66ddaff23e9846ba.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '625a8a4e89049d12931e2b956547539d',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/25b67fb21596f73e8507742b395e9a82.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35f40af5ede7ba2a0c3aad4479310ead',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/8bb47350ea52d8b87bb66c1c1dd76343.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89a8f49b8b5a188bb548212a37e6213',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/8bd164b82879f63238ab9f547c3db9ca.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '669bb2e97531298d840ad273cda7235b',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ad1c04ad97373a84877436a025f591f4.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6a88170ff67007cc76bec8195550d7e',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/8ddf1dc11dab4a078952f9881a89c316.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be85e1e965dc9ce1f024ca45c5d39c0f',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/4374c326cdad1fb8688410216cf53786.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd371e13f27bd1011a51c75781335648c',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/1beb6599422e004dc252ba4871e981bd.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '880a4ef205cf9e1c1c4c9095ccda3016',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/66ac10b45df9a528c164c440b5565686.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21322accec5cfcd778fa7e81765867e9',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/2116e9d1130b03153f69189f551ef12d.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f9a3d53ee36c180997b5252a7f731cc',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/5317ab21a61a214bee434e14f4937b84.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd26021853b8e9f0fe806bb55a73de951',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/9f91e33208b0c443bb60e69c2e51d16c.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1de4697a49657e8028717849920da88',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/567aebbff6f712fcf00e9e87209221e1.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeaec335ca9fcfce271f7b87a39e12e6',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/8ba8b569e081ac2c5c060170f3964c76.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf341a7cb69bf56e4fce6efb78068bb5',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/895aaddf8b309b799bcf0a2adea08260.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb17e735a1009826b37bfe45768bed9d',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/986c94c04f2901dec0b9fab4db5bcf29.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19aba131c30065b1e068014fe63017c9',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/764293c5e631c266907c60c2f32d58a7.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5feb2686dda26531513ac9237a2eec9',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/4a760c4c4c6b66e1257657d5a4e6f045.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef205e5445c2863e688cca6d5f96d1cc',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/ce14e1ca05395e4aaa58656662bfb5ac.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '477feed56ee66905f939a8c6014e4247',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/73eddcae09801382f7a1694a276911b5.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5e151a114a1e4bd2d9dd3ff2ae95f73',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/234437ad40b1c0619fd5c2778fb6fe85.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e12ca91da0f44b0679ced5eddded5c3',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/db240bad80782798a8379142efbfeac3.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf4758637987faafcf025423f0dd7f8f',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/808648ef8cc14f24bdafcab6fc1d4035.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb0234f6c55ce801c7ac291b99675fae',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/6fdf2d61017b43801c5883ae77da1846.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'fac8683971f6bd9333975d86cd3090d4',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/4021166ead098d1641c7806ec04e060b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8b7373a5c852b2b5418d693948a41b7c',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/97c5ad65497b7d9da9b5637c6885786d.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'b8c31e26548ef1dbf528ba972c98a1b7',
      'native_key' => 1,
      'filename' => 'modUserGroup/6ad359c272fb3bda3bc1a3be5f62f01b.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '2fbf9fe4cdcdfcbd75b517537946788e',
      'native_key' => 1,
      'filename' => 'modDashboard/1f2a9b33af47d90f2dd88e9a6fdfdf29.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '5f8de138b1ffd7eb4c82897459d9cc0c',
      'native_key' => 1,
      'filename' => 'modMediaSource/15638549b3d159f657e2f607c3a66527.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '55238e5b4806e829e92d2207c0145089',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ab66404f3bc5d361aa038fe9d3920a70.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '308f85895d30c00489777d39700c4de5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/60841a27b6f96003eba2b5e92bb61649.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd651b6229771b61d323f7fb728b062e6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/81be354a3b1dbcf3021d51c874613c54.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2d0da06535b033aa81ee03ca80a8a565',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bcaa383903027dc4932d33e960e944ea.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '18f878a816b29c51d25a41fcbc866026',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e9b583d5f73b7548de2beccd89e31744.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '13bbb4f38c45dbe4600da295ac5b4921',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/3913967d3d5bc9c3b7c0c0f93d51fabd.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '71b4066b80166d0739cc8a963e17b1e7',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/15d1bc205e9e43ccff1f1b6ed11ec1ae.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e2057a28187dda15e56b6b1020eed161',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c7c6a4a118f1e3c1f2904d77f563e42d.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '988f260431f1ada74355e6639d6e1782',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1e7f05e53313cd0737ab4334dc1d23d7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c27fa2001e27e40d20bf9c362adb777e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/911bcadb0093d92153970f7579e8509e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '47debe21d0ffba5acc6b0ace3c4e8bbb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/de7078288029d4366ade884c1940a053.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '44eabb63edeecfadc3e49aa86f54bbe2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/86350087f19d2d2a2e7c2e8ca6ddbbbe.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '118a24364818145e4f628bac453cb1d3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/350bac4471631cd16451f4384fded213.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '678cdcfa357f4ad19507d15f2d1e0d93',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/804e4ed73c575693a335b3d8830c882f.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '102167722ddd6e7623c54865b4c5a9c1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/81774912627edeff00f253bb0a517c72.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5f74521d9296be6b4e6e8f0d8a6ac516',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c8f5009f2c087304977b3385e7986ad2.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd3e785a60298a9e4770babc994f880ee',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d7cf490bcdba045ee5fdd3d63e1929bb.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5883ee5520dc18dd0b4dfc13b52549a6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/10ca0be7ea0187c46f267e3390fda6f6.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b1694a7e6ceb3b51f3f052403ba2b988',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7fd2761e067578c02fa579ea65659ca5.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2ebb6a164ee879df08e993cc85065a57',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/778921943dcf856bcfb06879429500f7.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '15b64b191ddbc7990fda947b57895d83',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/0e17e4c9e617ecb80385ebbc2f64269c.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1908aea16b11761483214cdb028d2f51',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/9acf248366445f2c97489a523de92c4f.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3f654c8e1af6005c727bc6cf0e2c3df5',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/f1ebe222f84129bc39862318e4d77755.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3d2caa193cfb3a0e911b9702ce9ed049',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/4b772a5148ea5cadae0b01587ca76168.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '76f267e3e9b6f1f835db37ebd504bd52',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/0805fc8ba528d40c96cbb883cc5a9cc5.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '74c80c90250eec6f9b1b3fcdb6f77e1a',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/1709ef3669fa1c35a13147ea9c5cf95d.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4e47e534ad621658d7024b2e483b9bf9',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/9e5ab268adf5be26b174d93b5d403db8.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a1974dec6adf242039ecd186924c4030',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/9b1dd9d28816a6847fb024f4ebe8a493.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4ed6d1bc89b0d407f6ab570a457bd44e',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/2f708d3f66a56704f86282a46efcbf47.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '50c34851710350b8619bbd9bc3e526c2',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/db6f0028707f1a3e32eebc463543f995.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '41654382630fe9b64ae5728421460041',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/f779dc010dc3143e326f132a49512ed1.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '113ee11d29bd686011ab4fa6f4328a2d',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/cea54503ea5839a2abff7bb5c481e4ee.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '37bae2a52870b4a077072228e331a09e',
      'native_key' => 'web',
      'filename' => 'modContext/f3b540208ce8847165ed470f565aa8e5.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '7c602f160fc641866e1a801baccb913e',
      'native_key' => 'mgr',
      'filename' => 'modContext/bec77a4968c46a87f653d1684f9e99db.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'af90304bcf8f5f9fc010cdfccb36b5ff',
      'native_key' => 'af90304bcf8f5f9fc010cdfccb36b5ff',
      'filename' => 'xPDOFileVehicle/f9c9800256f9db5291cc0d18f8879e8a.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '61df366d14fdd8e9dc27fc79ec129f4e',
      'native_key' => '61df366d14fdd8e9dc27fc79ec129f4e',
      'filename' => 'xPDOFileVehicle/611409e1b509aab4c2c03753fcf57ac9.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f5d000b2cbc19302fbffc6e7c3139d2d',
      'native_key' => 'f5d000b2cbc19302fbffc6e7c3139d2d',
      'filename' => 'xPDOFileVehicle/209264b62364f8abf5c74f45dfa2ccbc.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9c98cbd07fa3ebe17ab4e9a90c847055',
      'native_key' => '9c98cbd07fa3ebe17ab4e9a90c847055',
      'filename' => 'xPDOFileVehicle/c06bd645ea47b7635b7b3be3cbb3e7f8.vehicle',
    ),
  ),
);