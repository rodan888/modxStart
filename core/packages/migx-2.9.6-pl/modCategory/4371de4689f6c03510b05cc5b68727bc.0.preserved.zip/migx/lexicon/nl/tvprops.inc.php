<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */


$_lang['mig.tabs'] = 'Formulier tabs';
$_lang['mig.columns'] = 'Grid kolommen';
$_lang['mig.btntext'] = '"Voeg item toe" vervanging';
$_lang['mig.previewurl'] = 'Voorbeeld URL';
$_lang['mig.jsonvarkey'] = 'Voorbeeld JsonVarKey';
$_lang['mig.configs'] = 'Configuraties';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';
