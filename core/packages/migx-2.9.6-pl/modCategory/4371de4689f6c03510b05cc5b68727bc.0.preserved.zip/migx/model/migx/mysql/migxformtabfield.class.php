<?php
require_once (dirname(dirname(__FILE__)) . '/migxformtabfield.class.php');
class migxFormtabField_mysql extends migxFormtabField {}