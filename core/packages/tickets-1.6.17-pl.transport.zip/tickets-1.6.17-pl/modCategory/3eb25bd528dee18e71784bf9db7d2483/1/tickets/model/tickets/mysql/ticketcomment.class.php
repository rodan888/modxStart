<?php
require_once (dirname(dirname(__FILE__)) . '/ticketcomment.class.php');
class TicketComment_mysql extends TicketComment {}