<?php
require_once (dirname(dirname(__FILE__)) . '/ticketvote.class.php');
class TicketVote_mysql extends TicketVote {}